/**
 * wBlock Userscript Injector
 * Injects and manages userscripts from the native app
 */

(() => {

// iOS Safari keeps a frame alive while an extension event still holds its
// listener, so detach on pagehide or iframe-heavy pages run out of memory (#861).
const listenWhileShown = (event, listener) => {
    event.addListener(listener);
    window.addEventListener('pagehide', () => event.removeListener(listener));
    window.addEventListener('pageshow', (e) => { if (e.persisted) event.addListener(listener); });
};

// Debug logging flag - set to false to disable verbose console output
var WBLOCK_DEBUG_LOGGING = false;
var WBLOCK_WARM_START_CACHE_KEY = '__wblock_warm_start_v1';
var WBLOCK_WARM_START_LEASE_MS = 30 * 60 * 1000;
var WBLOCK_WARM_START_MAX_SCRIPTS = 4;
var WBLOCK_WARM_START_MAX_BYTES = 2 * 1024 * 1024;
var WBLOCK_DARK_READER_URL = 'https://raw.githubusercontent.com/0xCUB3/wBlock-userscripts/main/packages/dark-reader/dist/dark-reader.user.js';

// The warm-start cache lives in localStorage so a brand-new tab still gets the
// before-first-paint injection of eligible document-start scripts; the old
// sessionStorage cache was per-tab, which left the first navigation of every
// new tab on the slow native path. The trust model is unchanged: both stores
// are page-writable, the cache carries no bridge secrets, page-world entries
// only ever gain page authority, and content-world entries (Dark Reader) still
// require the digest check plus native validation before executing. The legacy
// sessionStorage entry is read as a fallback once and cleared on write.
function readWarmStartCache() {
    var raw = null;
    try { raw = localStorage.getItem(WBLOCK_WARM_START_CACHE_KEY); } catch (_) {}
    if (raw !== null) return raw;
    try { raw = sessionStorage.getItem(WBLOCK_WARM_START_CACHE_KEY); } catch (_) {}
    return raw;
}
function writeWarmStartCache(serialized) {
    try { localStorage.setItem(WBLOCK_WARM_START_CACHE_KEY, serialized); } catch (_) {}
    try { sessionStorage.removeItem(WBLOCK_WARM_START_CACHE_KEY); } catch (_) {}
}
function removeWarmStartCache() {
    try { localStorage.removeItem(WBLOCK_WARM_START_CACHE_KEY); } catch (_) {}
    try { sessionStorage.removeItem(WBLOCK_WARM_START_CACHE_KEY); } catch (_) {}
}

var wBlockLog = (...args) => {
    if (WBLOCK_DEBUG_LOGGING) {
        console.log(...args);
    }
};

var wBlockWarn = (...args) => {
    if (WBLOCK_DEBUG_LOGGING) {
        console.warn(...args);
    }
};

var wBlockError = (...args) => {
    // Always log errors
    console.error(...args);
};

// Escape a string for safe embedding inside a JavaScript string literal.
// Handles backslash, single/double quotes, backticks, newlines, and template
// literal interpolation sequences so that userscript metadata with special
// characters never produces malformed generated JavaScript.
function escapeForJS(str) {
    if (typeof str !== 'string') return '';
    return str
        .replace(/\\/g, '\\\\')
        .replace(/'/g, "\\'")
        .replace(/"/g, '\\"')
        .replace(/`/g, '\\`')
        .replace(/\n/g, '\\n')
        .replace(/\r/g, '\\r')
        .replace(/\$\{/g, '\\${');
}

// Page hooks may share these playback preferences, never a general GM capability.
const TUBE_SETTINGS_KEY = 'wblock.tubeCleaner.sponsorBlock';
function isTubeCleanerPageScript(script) {
    return script && script.isLocal === false
        && script.sourceURL === 'https://raw.githubusercontent.com/0xCUB3/wBlock-userscripts/main/packages/tube-cleaner/dist/tube-cleaner.user.js'
        && /(^|\.)youtube\.com$/i.test(location.hostname) && location.protocol === 'https:'
        && (script.grant || []).every(grant => ['none', 'unsafewindow', 'gm_info', 'gm.info',
            'gm_getvalue', 'gm.getvalue', 'gm_setvalue', 'gm.setvalue'].includes(String(grant).toLowerCase()));
}
function usesPageOnlyNetwork(script) {
    const grants = (script.grant || []).map(grant => String(grant).toLowerCase());
    // Loaders such as Vencord need page globals, but their public downloads do
    // not need extension authority. Keep normal page CSP/CORS checks intact.
    return script.injectInto !== 'content' && grants.includes('unsafewindow')
        && grants.every(grant => ['none', 'unsafewindow', 'gm_info', 'gm.info', 'gm_xmlhttprequest', 'gm.xmlhttprequest'].includes(grant));
}
// AdGuard Popup Blocker patches page globals (window.open, click) and exports its
// options API there, so it must run in MAIN. Its page storage persists only bounded
// allow/silence lists, and ordinary pages may change only their own host.
const POPUP_BLOCKER_URLS = new Set(['release', 'beta'].map(channel =>
    `https://userscripts.adtidy.org/${channel}/popup-blocker/2.5/popupblocker.user.js`));
const POPUP_BLOCKER_ID = /^[A-Za-z0-9+/=]{1,64}$/;
function isPopupBlockerPageScript(script) {
    return script && script.isLocal === false && POPUP_BLOCKER_URLS.has(script.sourceURL)
        && (script.grant || []).every(grant => ['unsafewindow', 'gm_getvalue', 'gm_setvalue', 'gm_deletevalue',
            'gm_listvalues', 'gm_getresourceurl'].includes(String(grant).toLowerCase()));
}
function isPopupBlockerOptionsPage() {
    return location.protocol === 'https:' && location.hostname === 'popupblocker.adguard.com'
        && /\/options\.html$/.test(location.pathname || '');
}
function popupBlockerHosts(value) {
    if (typeof value !== 'string' || value.length > 65536) return null;
    return [...new Set(value.toLowerCase().split(','))].filter(host => /^[a-z0-9.-]{1,253}$/.test(host)).slice(0, 2000);
}
function popupBlockerStorage(snapshot) {
    const state = {};
    for (const key of ['allowed', 'silenced', '#id']) {
        try {
            const value = JSON.parse((snapshot || {})[key]);
            if (key === '#id' ? typeof value === 'string' && POPUP_BLOCKER_ID.test(value) : popupBlockerHosts(value)) {
                state[key] = key === '#id' ? value : popupBlockerHosts(value).join(',');
            }
        } catch (_) { /* Missing or malformed values start empty. */ }
    }
    return state;
}
function pageStorageSnapshot(script) {
    // No arbitrary stored value is exposed to the page.
    if (isTubeCleanerPageScript(script)) {
        try {
            const parsed = boundedTubeSettings(JSON.parse((script.storageSnapshot || {})[TUBE_SETTINGS_KEY]));
            if (parsed) return { [TUBE_SETTINGS_KEY]: JSON.stringify(parsed) };
        } catch (_) { /* Fall through to an empty snapshot. */ }
        return {};
    }
    if (!isPopupBlockerPageScript(script)) return {};
    // Version 3 skips migrations, which would delete and rewrite every key.
    return Object.fromEntries([['ver', '3'], ...Object.entries(popupBlockerStorage(script.storageSnapshot))]
        .map(([key, value]) => [key, JSON.stringify(value)]));
}
function requiresIsolatedGM(script) {
    return !isTubeCleanerPageScript(script) && !isPopupBlockerPageScript(script) && !usesPageOnlyNetwork(script) && (script.grant || []).some(grant => {
        const name = String(grant).toLowerCase();
        return name.startsWith('gm') && name !== 'gm_info' && name !== 'gm.info';
    });
}
function boundedTubeSettings(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
    const keys = ['enabled', 'showNotice', 'minimumDuration', 'modes', 'excludedChannels'];
    if (Object.keys(value).some(key => !keys.includes(key))) return null;
    if (typeof value.enabled !== 'boolean' || typeof value.showNotice !== 'boolean'
        || !Number.isFinite(value.minimumDuration) || value.minimumDuration < 0 || value.minimumDuration > 86400
        || !value.modes || typeof value.modes !== 'object' || Array.isArray(value.modes)
        || !Array.isArray(value.excludedChannels) || value.excludedChannels.length > 200) return null;
    const categories = ['sponsor', 'selfpromo', 'interaction', 'intro', 'outro', 'preview', 'filler', 'music_offtopic'];
    if (Object.keys(value.modes).some(key => !categories.includes(key))) return null;
    const modes = {};
    for (const key of categories) {
        if (!['auto', 'ask', 'off'].includes(value.modes[key])) return null;
        modes[key] = value.modes[key];
    }
    if (value.excludedChannels.some(id => typeof id !== 'string' || id.length >= 200)) return null;
    return { enabled: value.enabled, showNotice: value.showNotice, minimumDuration: value.minimumDuration,
        modes, excludedChannels: value.excludedChannels.slice() };
}

// Best-effort CSP nonce detection for script-tag injection on strict CSP pages
var wBlockCachedCspNonce = null;
function getCspNonce() {
    if (wBlockCachedCspNonce) return wBlockCachedCspNonce;
    try {
        const el = document.querySelector('script[nonce]');
        const nonce = el ? (el.nonce || el.getAttribute('nonce') || '') : '';
        if (nonce) {
            wBlockCachedCspNonce = nonce;
        }
        return nonce || '';
    } catch (e) {
        return '';
    }
}

// Avoid inspecting frameElement. Safari logs cross-origin access errors even when
// they are caught, and content scripts run in ad iframes with cross-origin parents.
// Page-context injection already verifies execution with a DOM side effect.
function isSandboxedWithoutScripts() {
    return false;
}

// Prevent multiple executions of this entire script in the same context
if (window.wBlockUserscriptInjectorHasRun) {
    wBlockLog('[wBlock] Userscript injector already ran in this frame.');
} else {
    window.wBlockUserscriptInjectorHasRun = true;
    wBlockLog('[wBlock] Initializing Userscript Injector for this frame.');

    // Userscript execution engine
    class UserScriptEngine {
        constructor() {
            this.injectedScripts = new Set();
            this.injectingScripts = new Map();
            this.pendingScripts = []; // Scripts waiting for document to be ready
            this.messageListenerAttached = false; // Ensure listener is attached only once
            this.extensionContextAvailable = false;
            this.extensionContextUnavailableLogged = false;
            this.pendingNativeRequests = new Map(); // requestId -> { resolve, reject, timeoutId }
            this.pageMenuBridgeElements = new Map(); // bridgeId -> script element
            this.contentMenuCommandCallbacks = new Map(); // bridgeId -> Map(commandId, callback)
            this.registeredMenuCommands = new Map(); // bridgeId -> Map(commandId, descriptor)
            this.pendingMenuInvocations = new Map(); // requestId -> { resolve, timeoutId }
            this.scriptPayloadPromises = new Map(); // scriptId -> Promise<hydrated script>
            this.warmStartValidationPromises = new Map(); // script key -> native validation promise
            this.validationPrefetches = new Map(); // execution key -> { url, promise } for cold-path scripts
            this.documentStartRequestGeneration = 0;
            this.documentRootPromise = null; // earliest safe page-world injection point
            this.rydPrefetchEnabled = false;
            this.menuCommandSequence = 0;
            // Short, even steps: a failure that clears after 2 s should not
            // wait for an 8 s slot. The old 0.5/1.5/4/8 s ladder turned four
            // quick failures into a 14 s late injection (#991).
            this.userScriptRequestRetryDelays = [250, 500, 1000, 1000, 1000, 1000, 2000, 2000, 2000, 2000, 2000];
            wBlockLog('[wBlock] UserScriptEngine constructor called.');
            this.init();
        }

        init() {
            wBlockLog('[wBlock] UserScriptEngine init.');
            this.setupDocumentEventListeners();
            // Listen for response from native app before making any requests.
            // On Safari App Extensions, responses can arrive very quickly and be missed
            // if the listener isn't attached yet.
            this.setupMessageListener();
            if (!this.extensionContextAvailable) return;

            // Bridge GM menu command registration/invocation between userscripts
            // and the extension popup.
            this.setupMenuCommandBridge();

            // Bridge page-context GM storage writes through the extension/native layer.
            this.setupStorageBridge();

            // Privileged GM calls never arrive over page events.

            // Validate cached permissions before executing, with no native bridge privileges.
            const warmStartValidationDispatch = this.loadWarmStartScripts();
            if (warmStartValidationDispatch) {
                warmStartValidationDispatch
                    .catch(error => wBlockWarn('[wBlock] Warm-start integrity check failed:', error))
                    .finally(() => this.requestUserScripts());
            } else {
                this.requestUserScripts();
            }
        }

        invalidateDocumentStartSessionCache() {
            // Revoke privileges and every in-flight result from the previous
            // generation, then fetch one new authoritative result. Completed
            // execution keys stay intact so scripts are never hot-run twice.
            const generation = ++this.documentStartRequestGeneration;
            this.pendingScripts = [];
            this.tubeCleanerSettingsScript = null;
            this.popupBlockerScript = null;
            this.pendingPageWrites.clear();
            this.scriptPayloadPromises.clear();
            this.warmStartValidationPromises.clear();
            this.injectingScripts.clear();
            this.requestUserScripts(0, generation);
        }

        waitForDocumentRoot() {
            if (document.documentElement) {
                return Promise.resolve(document.documentElement);
            }
            if (this.documentRootPromise) {
                return this.documentRootPromise;
            }

            // Safari can run a document_start content script before the parser has
            // created <html>. The engine and native request should still start now;
            // only the final <script>/<style> insertion needs to wait. Observing the
            // Document resolves at the first parser mutation, well before
            // DOMContentLoaded and before page scripts in <head> execute.
            this.documentRootPromise = new Promise((resolve) => {
                let observer = null;
                const finishIfReady = () => {
                    if (!document.documentElement) return false;
                    if (observer) observer.disconnect();
                    resolve(document.documentElement);
                    return true;
                };

                if (finishIfReady()) return;
                if (typeof MutationObserver !== 'undefined') {
                    observer = new MutationObserver(finishIfReady);
                    observer.observe(document, { childList: true });
                    finishIfReady(); // close the check/observe race
                } else {
                    document.addEventListener('DOMContentLoaded', finishIfReady, { once: true });
                }
            });
            return this.documentRootPromise;
        }

        inlinePageScriptsCanRun() {
            const marker = `data-wblock-inline-${Math.random().toString(36).slice(2)}`;
            const probe = document.createElement('script');
            probe.textContent = `document.documentElement.setAttribute('${marker}', '1')`;
            document.documentElement.appendChild(probe);
            probe.remove();
            const executed = document.documentElement.getAttribute(marker) === '1';
            document.documentElement.removeAttribute(marker);
            return executed;
        }

        waitForCspNonce(timeoutMs = 1500) {
            const currentNonce = getCspNonce();
            if (currentNonce) return Promise.resolve(currentNonce);
            return new Promise(resolve => {
                const finish = () => {
                    const nonce = getCspNonce();
                    if (!nonce) return false;
                    observer.disconnect();
                    clearTimeout(timeoutId);
                    resolve(nonce);
                    return true;
                };
                const observer = new MutationObserver(finish);
                observer.observe(document, { childList: true, subtree: true });
                const timeoutId = setTimeout(() => {
                    observer.disconnect();
                    resolve('');
                }, timeoutMs);
                finish();
            });
        }

        setupStorageBridge() {
            this.tubeCleanerSettingsScript = null;
            this.popupBlockerScript = null;
            this.pendingPageWrites = new Map();
            this.pageWritesFlushing = false;
            window.addEventListener('message', event => {
                if (event.source !== window || !event.data) return;
                const write = event.data.type === 'wblock:tube-preferences' ? this.tubePreferenceWrite(event.data)
                    : event.data.type === 'wblock:popup-blocker-storage' ? this.popupBlockerWrite(event.data) : null;
                if (!write) return;
                // These values are intentionally page-writable, like localStorage.
                // Coalesce floods; the page cannot choose an action, script or identity.
                this.pendingPageWrites.set(write.key, { ...write, generation: this.documentStartRequestGeneration });
                if (!this.pageWritesFlushing) this.flushPageWrites();
            });
        }

        tubePreferenceWrite(data) {
            const script = this.tubeCleanerSettingsScript;
            const settings = script && isTubeCleanerPageScript(script) && boundedTubeSettings(data.settings);
            return settings ? { script, key: TUBE_SETTINGS_KEY, rawValue: JSON.stringify(settings) } : null;
        }

        popupBlockerWrite(data) {
            const script = this.popupBlockerScript;
            if (!script || !isPopupBlockerPageScript(script) || typeof data.rawValue !== 'string') return null;
            let value;
            try { value = JSON.parse(data.rawValue); } catch (_) { return null; }
            const state = this.popupBlockerState;
            if (data.key === '#id') {
                // The instance ID is generated once and never replaced.
                if (state['#id'] || typeof value !== 'string' || !POPUP_BLOCKER_ID.test(value)) return null;
                state['#id'] = value;
            } else if (data.key === 'allowed' || data.key === 'silenced') {
                const hosts = popupBlockerHosts(value);
                if (!hosts) return null;
                if (isPopupBlockerOptionsPage()) {
                    state[data.key] = hosts.join(',');
                } else {
                    const host = location.hostname.toLowerCase();
                    const others = popupBlockerHosts(state[data.key] || '').filter(entry => entry !== host);
                    state[data.key] = (hosts.includes(host) ? [...others, host] : others).join(',');
                }
            } else {
                return null;
            }
            return { script, key: data.key, rawValue: JSON.stringify(state[data.key]) };
        }

        async flushPageWrites() {
            this.pageWritesFlushing = true;
            try {
                for (let next; (next = this.pendingPageWrites.values().next().value);) {
                    this.pendingPageWrites.delete(next.key);
                    if (next.generation !== this.documentStartRequestGeneration) continue;
                    try {
                        await this.sendNativeRequest('setUserScriptStorageValue', {
                            scriptId: next.script.id, key: next.key, rawValue: next.rawValue
                        });
                    } catch (_) { /* Page-local settings still work offline. */ }
                    await new Promise(resolve => setTimeout(resolve, 250));
                }
            } finally {
                this.pageWritesFlushing = false;
            }
        }

        setupMenuCommandBridge() {
            window.__wBlockMenuCommandBridge = {
                registerMenuCommand: (bridgeId, commandId, details, callback) => {
                    if (typeof callback !== 'function') return;

                    let callbacks = this.contentMenuCommandCallbacks.get(bridgeId);
                    if (!callbacks) {
                        callbacks = new Map();
                        this.contentMenuCommandCallbacks.set(bridgeId, callbacks);
                    }
                    callbacks.set(commandId, callback);
                    this.registerMenuCommandDescriptor(bridgeId, commandId, details);
                },
                unregisterMenuCommand: (bridgeId, commandId) => {
                    const callbacks = this.contentMenuCommandCallbacks.get(bridgeId);
                    if (callbacks) {
                        callbacks.delete(commandId);
                        if (callbacks.size === 0) {
                            this.contentMenuCommandCallbacks.delete(bridgeId);
                        }
                    }
                    this.unregisterMenuCommandDescriptor(bridgeId, commandId);
                }
            };
            window.__wBlockUserscriptMenuState = this.getRegisteredMenuCommands();

            window.addEventListener('pagehide', () => {
                this.pageMenuBridgeElements.clear();
                this.contentMenuCommandCallbacks.clear();
                this.registeredMenuCommands.clear();
                window.__wBlockUserscriptMenuState = [];
                this.syncMenuCommandsToBackground();
            }, { once: true });
        }

        registerMenuCommandDescriptor(bridgeId, commandId, details = {}) {
            if (typeof bridgeId !== 'string' || typeof commandId !== 'string') {
                return;
            }

            const bridgeCommands = this.registeredMenuCommands.get(bridgeId) || new Map();
            const existing = bridgeCommands.get(commandId);
            bridgeCommands.set(commandId, {
                bridgeId,
                commandId,
                caption: typeof details.caption === 'string' ? details.caption : '',
                title: typeof details.title === 'string' ? details.title : '',
                accessKey: typeof details.accessKey === 'string' ? details.accessKey : '',
                scriptName: typeof details.scriptName === 'string' ? details.scriptName : '',
                sortOrder: existing ? existing.sortOrder : (++this.menuCommandSequence)
            });
            this.registeredMenuCommands.set(bridgeId, bridgeCommands);
            this.syncMenuCommandsToBackground();
        }

        unregisterMenuCommandDescriptor(bridgeId, commandId) {
            if (typeof bridgeId !== 'string' || typeof commandId !== 'string') {
                return;
            }

            const bridgeCommands = this.registeredMenuCommands.get(bridgeId);
            if (!bridgeCommands) {
                return;
            }

            bridgeCommands.delete(commandId);
            if (bridgeCommands.size === 0) {
                this.registeredMenuCommands.delete(bridgeId);
            }
            this.syncMenuCommandsToBackground();
        }

        syncMenuCommandsToBackground() {
            const commands = this.getRegisteredMenuCommands();
            window.__wBlockUserscriptMenuState = commands;

            if (!(typeof browser !== 'undefined' && browser.runtime && browser.runtime.sendMessage)) {
                return;
            }

            browser.runtime.sendMessage({
                action: 'wblock:menu:updateFrameCommands',
                commands
            }).catch((error) => {
                wBlockWarn('[wBlock] Failed to sync menu commands to background:', error);
            });
        }

        attachPageMenuCommandBridge(scriptElement, script) {
            const bridgeId = script && script.menuBridgeId;
            if (!bridgeId || !scriptElement) {
                return;
            }

            this.pageMenuBridgeElements.set(bridgeId, scriptElement);
            scriptElement.addEventListener('wblock-gm-menu-register', (event) => {
                const detail = event && event.detail ? event.detail : {};
                if (detail.bridgeId !== bridgeId || typeof detail.commandId !== 'string' || typeof detail.caption !== 'string') {
                    return;
                }
                this.registerMenuCommandDescriptor(bridgeId, detail.commandId, detail);
            });

            scriptElement.addEventListener('wblock-gm-menu-unregister', (event) => {
                const detail = event && event.detail ? event.detail : {};
                if (detail.bridgeId !== bridgeId || typeof detail.commandId !== 'string') {
                    return;
                }
                this.unregisterMenuCommandDescriptor(bridgeId, detail.commandId);
            });

            scriptElement.addEventListener('wblock-gm-menu-invoke-result', (event) => {
                const detail = event && event.detail ? event.detail : {};
                if (detail.bridgeId !== bridgeId || typeof detail.requestId !== 'string') {
                    return;
                }

                const pending = this.pendingMenuInvocations.get(detail.requestId);
                if (!pending) {
                    return;
                }

                this.pendingMenuInvocations.delete(detail.requestId);
                clearTimeout(pending.timeoutId);
                pending.resolve({
                    ok: detail.success !== false,
                    error: typeof detail.error === 'string' ? detail.error : ''
                });
            });
        }

        getRegisteredMenuCommands() {
            const commands = [];
            this.registeredMenuCommands.forEach((bridgeCommands) => {
                bridgeCommands.forEach((descriptor) => {
                    commands.push(descriptor);
                });
            });

            commands.sort((left, right) => left.sortOrder - right.sortOrder);
            return commands.map(({ bridgeId, commandId, caption, title, accessKey, scriptName, sortOrder }) => ({
                bridgeId,
                commandId,
                caption,
                title,
                accessKey,
                scriptName,
                sortOrder
            }));
        }

        async invokeMenuCommand(bridgeId, commandId) {
            if (typeof bridgeId !== 'string' || typeof commandId !== 'string') {
                return { ok: false, error: 'Invalid menu command request' };
            }

            const contentCallbacks = this.contentMenuCommandCallbacks.get(bridgeId);
            if (contentCallbacks && contentCallbacks.has(commandId)) {
                try {
                    await Promise.resolve(contentCallbacks.get(commandId)());
                    return { ok: true, error: '' };
                } catch (error) {
                    return {
                        ok: false,
                        error: error && error.message ? error.message : String(error)
                    };
                }
            }

            const bridgeElement = this.pageMenuBridgeElements.get(bridgeId);
            if (!bridgeElement) {
                return { ok: false, error: 'Menu command not found' };
            }

            const requestId = this.generateRequestId('gmmenuinvoke');
            return await new Promise((resolve) => {
                const timeoutId = setTimeout(() => {
                    this.pendingMenuInvocations.delete(requestId);
                    resolve({ ok: false, error: 'Menu command timed out' });
                }, 15000);

                this.pendingMenuInvocations.set(requestId, { resolve, timeoutId });
                bridgeElement.dispatchEvent(new CustomEvent('wblock-gm-menu-invoke', {
                    detail: { bridgeId, commandId, requestId }
                }));
            });
        }



        generateRequestId(prefix) {
            return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2)}`;
        }

        // Unique identifiers for popup commands and isolated runtime streams.
        // These are not authentication for messages from the page.
        generateSecret(prefix) {
            const bytes = new Uint8Array(16);
            if (typeof crypto !== 'undefined' && typeof crypto.getRandomValues === 'function') {
                crypto.getRandomValues(bytes);
            } else {
                for (let i = 0; i < bytes.length; i += 1) {
                    bytes[i] = Math.floor(Math.random() * 256);
                }
            }
            let hex = '';
            for (let i = 0; i < bytes.length; i += 1) {
                hex += bytes[i].toString(16).padStart(2, '0');
            }
            return `${prefix}-${hex}`;
        }

        async sendNativeRequest(action, payload = {}) {
            const requestId = payload.requestId || this.generateRequestId(action);
            const messagePayload = { ...payload, requestId };

            if (typeof browser !== 'undefined' && browser.runtime && browser.runtime.sendMessage) {
                return await browser.runtime.sendMessage({ action, ...messagePayload });
            }

            if (typeof safari !== 'undefined' && safari.extension && safari.extension.dispatchMessage) {
                return await new Promise((resolve, reject) => {
                    const timeoutMs = (typeof action === 'string' && action.includes('Chunk')) ? 120000 : 15000;
                    const timeoutId = setTimeout(() => {
                        this.pendingNativeRequests.delete(requestId);
                        reject(new Error(`[wBlock] Native request timeout: ${action}`));
                    }, timeoutMs);

                    this.pendingNativeRequests.set(requestId, { resolve, reject, timeoutId });
                    safari.extension.dispatchMessage(action, messagePayload);
                });
            }

            throw new Error('[wBlock] No suitable messaging API found for native requests.');
        }

        getPreferredChunkSize() {
            // 32 KB chunks were too conservative and forced dozens of native round-trips
            // for large scripts. 512 KB keeps chunked hydration bounded without making
            // individual native messages unusually large.
            return 512 * 1024; // bytes, before base64 expansion
        }

        base64ToBytes(base64) {
            const binary = atob(base64);
            const bytes = new Uint8Array(binary.length);
            for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
            return bytes;
        }

        concatBytes(arrays) {
            const totalLength = arrays.reduce((sum, arr) => sum + arr.length, 0);
            const out = new Uint8Array(totalLength);
            let offset = 0;
            for (const arr of arrays) {
                out.set(arr, offset);
                offset += arr.length;
            }
            return out;
        }

        async fetchTextFromChunks(action, params) {
            const decoder = new TextDecoder('utf-8');
            const chunkSize = this.getPreferredChunkSize();
            const first = await this.sendNativeRequest(action, { ...params, chunkIndex: 0, chunkSize });
            if (first && first.error) throw new Error(first.error);

            const totalChunks = (first && typeof first.totalChunks === 'number') ? first.totalChunks : 1;
            if (!Number.isInteger(totalChunks) || totalChunks < 1 || totalChunks > 256) {
                throw new Error('Invalid userscript chunk response');
            }
            const payloadRevision = first && first.payloadRevision;
            if (!Number.isSafeInteger(payloadRevision) || payloadRevision < 0) {
                throw new Error('Missing userscript payload revision');
            }

            const chunks = new Array(totalChunks);
            if (!first || typeof first.chunk !== 'string') {
                throw new Error('Missing userscript chunk data');
            }
            chunks[0] = first.chunk;

            // Request the remaining chunks with bounded concurrency instead of strictly
            // sequentially. On the Safari App Extension path these run in parallel; on the
            // browser.runtime path the background serializes native messages anyway, but
            // issuing them together avoids per-chunk JS await stalls. Either way this
            // shortens hydration so even chunked document-start scripts inject sooner.
            const maxConcurrentChunkRequests = 6;
            let nextChunkIndex = 1;
            const fetchChunkWorker = async () => {
                for (;;) {
                    const i = nextChunkIndex++;
                    if (i >= totalChunks) return;
                    const resp = await this.sendNativeRequest(action, { ...params, chunkIndex: i, chunkSize, payloadRevision });
                    if (resp && resp.error) throw new Error(resp.error);
                    if (!resp || typeof resp.chunk !== 'string') {
                        throw new Error('Missing userscript chunk data');
                    }
                    chunks[i] = resp.chunk;
                }
            };
            const workerCount = Math.min(maxConcurrentChunkRequests, Math.max(0, totalChunks - 1));
            const workers = [];
            for (let w = 0; w < workerCount; w++) {
                workers.push(fetchChunkWorker());
            }
            await Promise.all(workers);

            const byteArrays = chunks.map(c => this.base64ToBytes(c));
            return decoder.decode(this.concatBytes(byteArrays));
        }

        async ensureScriptPayload(script) {
            if (script && typeof script.content === 'string' && script.content.length > 0) {
                // Hydrated payload may already include content/resources.
                if (script.resources == null && script.resourceContents != null) {
                    script.resources = script.resourceContents;
                }
                return script;
            }

            if (!script || !script.id) {
                throw new Error('Userscript descriptor missing id');
            }

            if (this.scriptPayloadPromises.has(script.id)) {
                return await this.scriptPayloadPromises.get(script.id);
            }

            const payloadPromise = (async () => {
                const chunkParams = {
                    scriptId: script.id,
                    payloadRevision: script.payloadRevision
                };
                // Native validates the page URL and revision for the first request.
                // Repeat the URL on every request so a chunk cannot cross pages.
                chunkParams.url = window.location.href;
                const content = await this.fetchTextFromChunks('getUserScriptContentChunk', chunkParams);
                const resourceNames = Array.isArray(script.resourceNames) ? script.resourceNames : [];
                const resources = {};
                for (const resourceName of resourceNames) {
                    resources[resourceName] = await this.fetchTextFromChunks('getUserScriptResourceChunk', {
                        ...chunkParams,
                        resourceName
                    });
                }

                return { ...script, content, resources };
            })();

            this.scriptPayloadPromises.set(script.id, payloadPromise);
            try {
                return await payloadPromise;
            } catch (error) {
                this.scriptPayloadPromises.delete(script.id);
                throw error;
            }
        }

        setupDocumentEventListeners() {
            // Listen for document ready states to inject pending scripts
            if (document.readyState === 'loading') {
                wBlockLog('[wBlock] Document is loading, setting up event listeners for ready states.');
                
                document.addEventListener('DOMContentLoaded', () => {
                    wBlockLog('[wBlock] DOMContentLoaded event fired, retrying pending scripts.');
                    this.retryPendingScripts();
                });
                
                window.addEventListener('load', () => {
                    wBlockLog('[wBlock] Window load event fired, retrying pending scripts.');
                    this.retryPendingScripts();
                });

                if (!document.body && typeof MutationObserver !== 'undefined') {
                    const bodyObserver = new MutationObserver(() => {
                        if (!document.body) return;
                        bodyObserver.disconnect();
                        wBlockLog('[wBlock] document.body appeared, retrying pending scripts.');
                        this.retryPendingScripts();
                    });
                    bodyObserver.observe(document.documentElement || document, { childList: true, subtree: true });
                }
            } else {
                wBlockLog(`[wBlock] Document already ready (${document.readyState}), no need for event listeners.`);
            }
        }

        async retryPendingScripts() {
            if (this.pendingScripts.length === 0) {
                wBlockLog('[wBlock] No pending scripts to retry.');
                return;
            }

            wBlockLog(`[wBlock] Retrying ${this.pendingScripts.length} pending scripts...`);
            const scriptsToRetry = [...this.pendingScripts];
            this.pendingScripts = [];
            for (const script of scriptsToRetry) {
                await this.injectUserScript(script);
            }
        }
        scriptMatchesCurrentURL(script) {
            try {
                const pageURL = new URL(window.location.href);
                const host = pageURL.hostname.toLowerCase();
                if (Object.prototype.hasOwnProperty.call(script, 'allowedHosts')
                    && (!Array.isArray(script.allowedHosts) || !script.allowedHosts.some(value => {
                        const allowed = String(value).trim().toLowerCase();
                        return allowed && (host === allowed || host.endsWith('.' + allowed));
                    }))) return false;
                const disabled = Array.isArray(script.disabledHosts) ? script.disabledHosts : [];
                if (disabled.some(value => {
                    const blocked = String(value).trim().toLowerCase();
                    return blocked && (host === blocked || host.endsWith('.' + blocked));
                })) return false;

                return (Array.isArray(script.matches) ? script.matches : []).some(pattern => {
                    const match = String(pattern).match(/^([^:]+):\/\/([^/]+)(\/.*)$/);
                    if (!match) return false;
                    const scheme = match[1].toLowerCase();
                    const schemeMatches = scheme === '*'
                        ? pageURL.protocol === 'http:' || pageURL.protocol === 'https:'
                        : pageURL.protocol === scheme + ':';
                    if (!schemeMatches) return false;

                    const hostPattern = match[2].toLowerCase();
                    const hostMatches = hostPattern === '*'
                        || hostPattern === host
                        || (hostPattern.startsWith('*.')
                            && (host === hostPattern.slice(2) || host.endsWith('.' + hostPattern.slice(2))));
                    if (!hostMatches) return false;

                    const pathPattern = match[3].replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*');
                    return new RegExp('^' + pathPattern + '$').test(pageURL.pathname + pageURL.search + pageURL.hash);
                });
            } catch (_) { return false; }
        }

        isWarmStartEligible(script) {
            if (!script || script.isEnabled !== true) return false;
            if (script.runAt !== 'document-start'
                || script.noframes === true && window !== window.top) return false;
            if (script.kind === 'style') return this.isStyleWarmStartEligible(script);
            const isRemote = script.isLocal === false && /^https:\/\//i.test(script.sourceURL || '');
            // Cached page scripts retain page authority only, even after validation.
            const isPageWarmStart = script.injectInto === 'page' && (isRemote || script.isLocal === true);
            const isDarkReaderContentWarmStart = isRemote
                && script.injectInto === 'content'
                && script.sourceURL === WBLOCK_DARK_READER_URL
                && typeof script.contentDigest === 'string'
                && /^[0-9a-f]{64}$/.test(script.contentDigest);
            if (!isPageWarmStart && !isDarkReaderContentWarmStart) return false;
            if (isPageWarmStart && requiresIsolatedGM(script)) return false;
            if (typeof script.content !== 'string' || !script.content) return false;
            if (!this.scriptMatchesCurrentURL(script)) return false;
            if ((script.includes || []).length || (script.excludes || []).length || (script.excludeMatches || []).length) return false;
            if ((script.resourceNames || []).length || (script.resourceURLs || []).length
                || script.resources && Object.keys(script.resources).length
                || Object.prototype.hasOwnProperty.call(script, 'storageSnapshot')) return false;
            if (script.storageBridgeId || script.menuBridgeId || script.xhrBridgeId || script.portBridgeId) return false;
            const safeGrants = new Set(['none', 'unsafewindow', 'gm_info', 'gm.info']);
            // Content-world GM_xmlhttpRequest holds no secret; the background
            // checks each request against native policy for this script and page.
            if (usesPageOnlyNetwork(script) || isDarkReaderContentWarmStart) {
                safeGrants.add('gm_xmlhttprequest'); safeGrants.add('gm.xmlhttprequest');
            }
            const grants = Array.isArray(script.grant) ? script.grant : [];
            return grants.every(grant => safeGrants.has(String(grant).toLowerCase()));
        }

        // Cached CSS needs both a matching digest and current site permission.
        isStyleWarmStartEligible(style) {
            if (typeof style.content !== 'string' || !style.content) return false;
            if (typeof style.contentDigest !== 'string' || !/^[0-9a-f]{64}$/.test(style.contentDigest)) return false;
            if (!this.scriptMatchesCurrentURL(style)) return false;
            if ((style.includes || []).length || (style.excludes || []).length || (style.excludeMatches || []).length) return false;
            return true;
        }

        loadWarmStartScripts() {
            try {
                const raw = readWarmStartCache();
                if (!raw) return null;
                if (new TextEncoder().encode(raw).length > WBLOCK_WARM_START_MAX_BYTES) {
                    removeWarmStartCache();
                    return;
                }
                const cache = JSON.parse(raw);
                const age = cache && Number.isFinite(cache.savedAt) ? Date.now() - cache.savedAt : -1;
                const readable = cache && cache.version === 1 && Array.isArray(cache.scripts);
                // The guard is plain CSS, so it needs no trust and outlives the lease.
                const darkReader = readable && cache.scripts.find(script => script && script.isEnabled === true
                    && script.sourceURL === WBLOCK_DARK_READER_URL && this.scriptMatchesCurrentURL(script));
                if (darkReader) this.showDarkReaderGuard(darkReader);
                if (!readable || age < 0 || age > WBLOCK_WARM_START_LEASE_MS) {
                    removeWarmStartCache();
                    return;
                }
                const scripts = cache.scripts
                    .filter(script => this.isWarmStartEligible(script))
                    .slice(0, WBLOCK_WARM_START_MAX_SCRIPTS)
                    .map(script => {
                        const {
                            storageBridgeId, menuBridgeId, xhrBridgeId, portBridgeId,
                            storageSnapshot, __wblockWarmStart, ...cached
                        } = script;
                        return { ...cached, __wblockWarmStart: true };
                    });
                if (scripts.length) {
                    const validationDispatch = this.prepareWarmStartValidations(scripts);
                    this.injectUserScripts(scripts);
                    return validationDispatch;
                }
            } catch (error) {
                wBlockWarn('[wBlock] Warm-start cache rejected:', error);
                removeWarmStartCache();
            }
            return null;
        }

        // Dark Reader waits on native validation, which lands well after first
        // paint. Paint the root dark meanwhile (#973). The guard goes just before
        // Dark Reader runs, since its adapter installs its own and must not
        // measure ours, or once this load turns out not to run it.
        showDarkReaderGuard(script) {
            if (window !== window.top) return;
            const followsSystem = !String(script.content).startsWith('const __wblockDarkReaderFollowsSystemAppearance = false;');
            if (followsSystem && !(typeof matchMedia === 'function' && matchMedia('(prefers-color-scheme: dark)').matches)) return;
            const guard = document.createElement('style');
            // Dark Reader's own fallback, so the page looks the same once it takes over.
            guard.textContent = 'html { color-scheme: dark !important; } html, body, body :not(iframe) { background-color: #181a1b !important; border-color: #776e62 !important; color: #e8e6e3 !important; }';
            this.darkReaderGuard = guard;
            this.waitForDocumentRoot().then(root => {
                if (this.darkReaderGuard === guard) root.appendChild(guard);
            });
            setTimeout(() => this.removeDarkReaderGuard(), 3000);
        }

        removeDarkReaderGuard(script) {
            if (!this.darkReaderGuard || script && script.sourceURL !== WBLOCK_DARK_READER_URL) return;
            this.darkReaderGuard.remove();
            this.darkReaderGuard = null;
        }

        async warmStartContentDigest(content) {
            if (typeof crypto === 'undefined' || !crypto.subtle || typeof crypto.subtle.digest !== 'function') {
                return null;
            }
            const bytes = new TextEncoder().encode(content);
            const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', bytes));
            return Array.from(digest, byte => byte.toString(16).padStart(2, '0')).join('');
        }

        prepareWarmStartValidations(scripts) {
            const validationDispatches = [];
            for (const script of scripts) {
                if (!this.isWarmStartEligible(script)) continue;
                const key = this.scriptExecutionKey(script);
                let markDispatched;
                const dispatched = new Promise(resolve => { markDispatched = resolve; });
                const validation = (async () => {
                    try {
                        if (script.injectInto === 'content' || script.kind === 'style') {
                            const actualDigest = await this.warmStartContentDigest(script.content);
                            if (actualDigest !== script.contentDigest) return { ok: false, error: 'userscript-integrity-mismatch' };
                        }
                        const nativeValidation = this.requestScriptValidation(script);
                        markDispatched();
                        return await nativeValidation;
                    } finally {
                        markDispatched();
                    }
                })();
                this.warmStartValidationPromises.set(key, validation);
                validationDispatches.push(dispatched);
            }
            return validationDispatches.length > 0 ? Promise.all(validationDispatches) : null;
        }

        persistWarmStartScripts(scripts) {
            try {
                const savedAt = Date.now();
                const bounded = [];
                for (const script of scripts) {
                    if (bounded.length >= WBLOCK_WARM_START_MAX_SCRIPTS) break;
                    if (!this.isWarmStartEligible(script)) continue;
                    const {
                        storageBridgeId, menuBridgeId, xhrBridgeId, portBridgeId,
                        storageSnapshot, __wblockWarmStart, ...cached
                    } = script;
                    const candidate = JSON.stringify({ version: 1, savedAt, scripts: [...bounded, cached] });
                    if (new TextEncoder().encode(candidate).length <= WBLOCK_WARM_START_MAX_BYTES) {
                        bounded.push(cached);
                    }
                }
                writeWarmStartCache(JSON.stringify({ version: 1, savedAt, scripts: bounded }));
            } catch (_) { /* page storage is optional */ }
        }

        requestUserScripts(attempt = 0, generation = this.documentStartRequestGeneration) {
            if (generation !== this.documentStartRequestGeneration) return;
            const url = window.location.href;
            wBlockLog(`[wBlock] Requesting userscripts for URL: ${url}`);

            this.sendNativeRequest('getUserScripts', {
                url,
                includeContent: true,
                // Conservative per-script cap for ordinary scripts. The native side grants
                // document-start scripts a larger allowance so timing-critical shims arrive
                // inline (no chunked round-trips) and can run before the page's own code.
                maxInlineContentBytes: 128 * 1024
            })
                .then((response) => {
                    if (generation !== this.documentStartRequestGeneration) return;
                    if (response && response.error) {
                        throw new Error(response.error);
                    }

                    const scripts = response && response.userScripts ? response.userScripts : [];
                    this.persistWarmStartScripts(scripts);
                    if (!scripts.some(script => script && script.sourceURL === WBLOCK_DARK_READER_URL)) this.removeDarkReaderGuard();
                    this.enableReturnYouTubeDislikePrefetch(scripts);
                    if (scripts.length === 0) wBlockLog('[wBlock] No userscripts found in getUserScripts response.');
                    this.injectUserScripts(scripts, generation);
                })
                .catch((error) => {
                    this.retryUserScriptRequest(attempt, error, generation);
                });
        }

        enableReturnYouTubeDislikePrefetch(scripts) {
            if (this.rydPrefetchEnabled || typeof fetch !== 'function') return;
            const hasRYD = scripts.some((script) =>
                script && script.name === 'Return YouTube Dislike'
                    && /^https:\/\/raw\.githubusercontent\.com\/Anarios\/return-youtube-dislike\//i.test(script.sourceURL || '')
            );
            if (!hasRYD) return;

            this.rydPrefetchEnabled = true;
            const prefetchCurrentVideo = () => setTimeout(() => this.prefetchReturnYouTubeDislike(), 0);
            document.addEventListener('yt-navigate-start', prefetchCurrentVideo, true);
            this.prefetchReturnYouTubeDislike();
        }

        prefetchReturnYouTubeDislike() {
            const pageURL = new URL(window.location.href);
            if (!/(^|\.)youtube\.com$/i.test(pageURL.hostname) || pageURL.hostname === 'music.youtube.com') return;
            const videoId = pageURL.pathname.startsWith('/shorts/')
                ? pageURL.pathname.split('/')[2]
                : pageURL.searchParams.get('v');
            if (!/^[A-Za-z0-9_-]{11}$/.test(videoId || '')) return;

            const url = `https://returnyoutubedislikeapi.com/votes?videoId=${encodeURIComponent(videoId)}`;
            fetch(url).then(response => response.text()).catch(() => {});
        }

        retryUserScriptRequest(attempt, error, generation = this.documentStartRequestGeneration) {
            const delay = this.userScriptRequestRetryDelays[attempt];
            if (typeof delay !== 'number') {
                wBlockError('[wBlock] Failed to request userscripts:', error);
                return;
            }
            wBlockError(`[wBlock] Userscript request ${attempt + 1} failed, retrying in ${delay} ms:`, error);

            setTimeout(() => {
                if (generation === this.documentStartRequestGeneration) {
                    this.requestUserScripts(attempt + 1, generation);
                }
            }, delay);
        }

        setupMessageListener() {
            if (this.messageListenerAttached) {
                wBlockLog('[wBlock] Message listener already attached.');
                return;
            }
            wBlockLog('[wBlock] Setting up message listener.');

            if (typeof browser !== 'undefined' && browser.runtime && browser.runtime.onMessage) {
                wBlockLog('[wBlock] Using browser.runtime.onMessage for listening.');
                listenWhileShown(browser.runtime.onMessage, (message, sender, sendResponse) => {
                    wBlockLog('[wBlock] Received message via browser.runtime.onMessage:', JSON.parse(JSON.stringify(message || {})));

                    if (message && message.type === 'wblock:pageSupportProbe') {
                        return Promise.resolve({
                            ok: true,
                            host: typeof location !== 'undefined' ? location.hostname : '',
                            protocol: typeof location !== 'undefined' ? location.protocol : '',
                        });
                    }

                    if (message && message.type === 'wblock:clearDocumentStartSessionCache') {
                        this.invalidateDocumentStartSessionCache();
                        return Promise.resolve({ ok: true });
                    }

                    if (message && message.type === 'wblock:menu:invokeCommand') {
                        return this.invokeMenuCommand(message.bridgeId, message.commandId);
                    }

                    if (message && message.type === 'wblock:menu:syncState') {
                        this.syncMenuCommandsToBackground();
                        return Promise.resolve({ ok: true });
                    }

                    if (message && message.type === 'wblock:gm-port-message') {
                        // Isolated wrappers receive this directly from runtime.onMessage.
                        return Promise.resolve({ ok: true });
                    }

                    let scriptsToInject = null;
                    if (message && message.userScripts) {
                        scriptsToInject = message.userScripts;
                    } else if (message && message.payload && message.payload.userScripts) {
                        scriptsToInject = message.payload.userScripts;
                    }

                    if (scriptsToInject) {
                        wBlockLog('[wBlock] Extracted userscripts from message (browser.runtime.onMessage):', scriptsToInject);
                        this.injectUserScripts(scriptsToInject);
                    } else {
                        wBlockLog('[wBlock] No userscripts found in received message (browser.runtime.onMessage).');
                    }

                });
                this.messageListenerAttached = true;
                this.extensionContextAvailable = true;
                wBlockLog('[wBlock] browser.runtime.onMessage listener attached.');
            } else if (typeof safari !== 'undefined' && safari.extension && typeof safari.self !== 'undefined' && safari.self.addEventListener) {
                wBlockLog('[wBlock] Using safari.self.addEventListener for listening.');
                safari.self.addEventListener('message', (event) => {
                    wBlockLog('[wBlock] Received message via safari.self.addEventListener:', event.name, JSON.parse(JSON.stringify(event.message || {})));
                    const requestId = event.message && event.message.requestId;
                    if (requestId && this.pendingNativeRequests.has(requestId)) {
                        const pending = this.pendingNativeRequests.get(requestId);
                        this.pendingNativeRequests.delete(requestId);
                        if (pending && pending.timeoutId) clearTimeout(pending.timeoutId);
                        pending.resolve(event.message);
                        return;
                    }
                    if (event.name === 'wblock:clearDocumentStartSessionCache') {
                        this.invalidateDocumentStartSessionCache();
                        return;
                    }
                    let scriptsToInject = null;
                    if ((event.name === 'getUserScripts' || event.name === 'requestUserScripts') && event.message && event.message.userScripts) {
                        scriptsToInject = event.message.userScripts;
                    } else if (event.name === 'requestRules' && event.message && event.message.payload && event.message.payload.userScripts) {
                        scriptsToInject = event.message.payload.userScripts;
                    }

                    if (scriptsToInject) {
                        wBlockLog('[wBlock] Extracted userscripts from message (safari.self.addEventListener):', scriptsToInject);
                        this.injectUserScripts(scriptsToInject);
                    } else {
                        wBlockLog('[wBlock] No userscripts found in received message (safari.self.addEventListener).');
                    }
                }, false);
                this.messageListenerAttached = true;
                this.extensionContextAvailable = true;
                wBlockLog('[wBlock] safari.self.addEventListener listener attached.');
            } else {
                if (!this.extensionContextUnavailableLogged) {
                    this.extensionContextUnavailableLogged = true;
                    wBlockWarn('[wBlock] Extension context is unavailable in this frame.');
                }
            }
        }

        injectUserScripts(userScripts, generation = this.documentStartRequestGeneration) {
            if (generation !== this.documentStartRequestGeneration) return;
            wBlockLog('[wBlock] injectUserScripts called with:', userScripts);
            if (!Array.isArray(userScripts)) {
                wBlockWarn('[wBlock] injectUserScripts called with non-array:', userScripts);
                return;
            }
            if (userScripts.length === 0) {
                wBlockLog('[wBlock] No userscripts to inject.');
                return;
            }
            const runAtPriority = { 'document-start': 0, 'document-body': 1, 'document-end': 2, 'document-idle': 3 };
            const orderedScripts = [...userScripts].sort((left, right) => {
                const leftPriority = runAtPriority[left && left.runAt] ?? 2;
                const rightPriority = runAtPriority[right && right.runAt] ?? 2;
                return leftPriority - rightPriority;
            });

            // Hydrate payloads and dispatch native execution validation for every
            // document-start script up front. The ordered loop below still executes
            // scripts one at a time, but their native round-trips overlap instead of
            // serializing, so a queued script no longer loses the race against the
            // page's own code just because other scripts are enabled (issue #537).
            orderedScripts
                .filter(script => script && script.runAt === 'document-start' && script.id)
                .forEach(script => {
                    this.ensureScriptPayload(script)
                        .then(fullScript => this.prefetchScriptValidation(fullScript))
                        .catch(error => {
                            wBlockWarn(`[wBlock] Failed to preload userscript payload for ${script.name}:`, error);
                        });
                });

            // Await each script: payload hydration and execution must preserve native order.
            const runInOrder = async () => {
                for (const script of orderedScripts) {
                    if (generation !== this.documentStartRequestGeneration) return;
                    await this.injectUserScript(script, generation);
                }
            };
            runInOrder().catch(error => wBlockWarn('[wBlock] Ordered userscript injection failed:', error));
        }

        scriptExecutionKey(script) {
            return script && script.id ? String(script.id) : String(script && script.name || '');
        }

        async injectUserScript(script, generation = this.documentStartRequestGeneration) {
            if (generation !== this.documentStartRequestGeneration) return;
            if (!script || !script.name) {
                wBlockWarn('[wBlock] Attempted to inject invalid script object:', script);
                return;
            }
            wBlockLog(`[wBlock] Processing userscript: ${script.name}`);

            const executionKey = this.scriptExecutionKey(script);
            if (this.injectedScripts.has(executionKey)) {
                wBlockLog(`[wBlock] Userscript ${script.name} already injected. Skipping.`);
                return;
            }
            if (this.injectingScripts.get(executionKey) === generation) {
                wBlockLog(`[wBlock] Userscript ${script.name} is already being injected. Skipping.`);
                return;
            }

            await this.injectSingleScriptAsync(script, generation);
        }

        requestScriptValidation(script) {
            return this.sendNativeRequest('validateUserScriptExecution', {
                scriptId: script.id,
                url: window.location.href,
                payloadRevision: script.payloadRevision,
                ...(typeof script.contentDigest === 'string' && script.contentDigest.length > 0
                    ? { contentDigest: script.contentDigest } : {})
            });
        }

        prefetchScriptValidation(script) {
            if (!script || !script.id || script.__wblockWarmStart === true) return;
            if (!Number.isSafeInteger(script.payloadRevision) || script.payloadRevision < 0) return;
            const executionKey = this.scriptExecutionKey(script);
            if (this.injectedScripts.has(executionKey)) return;
            const url = window.location.href;
            const existing = this.validationPrefetches.get(executionKey);
            if (existing && existing.url === url && existing.payloadRevision === script.payloadRevision) return;
            const promise = this.requestScriptValidation(script);
            // The outcome is consumed (or the request retried) in
            // validateScriptForExecution; never surface an unhandled rejection here.
            promise.catch(() => {});
            this.validationPrefetches.set(executionKey, { url, payloadRevision: script.payloadRevision, promise });
        }

        async validateScriptForExecution(script) {
            if (!script || !script.id || !Number.isSafeInteger(script.payloadRevision) || script.payloadRevision < 0) {
                return false;
            }
            const executionKey = this.scriptExecutionKey(script);
            const warmValidation = script.__wblockWarmStart === true
                ? this.warmStartValidationPromises.get(executionKey)
                : null;
            let result;
            if (warmValidation) {
                result = await warmValidation;
            } else {
                const prefetched = this.validationPrefetches.get(executionKey);
                this.validationPrefetches.delete(executionKey);
                if (prefetched && prefetched.url === window.location.href
                    && prefetched.payloadRevision === script.payloadRevision) {
                    try {
                        result = await prefetched.promise;
                    } catch (_) {
                        result = await this.requestScriptValidation(script);
                    }
                } else {
                    result = await this.requestScriptValidation(script);
                }
            }
            if (!result || result.ok !== true) {
                if (result && result.error) wBlockLog(`[wBlock] Native execution validation rejected ${script.name}: ${result.error}`);
                return false;
            }
            return true;
        }

        injectSingleScript(script, generation = this.documentStartRequestGeneration) {
            this.injectSingleScriptAsync(script, generation).catch((error) => {
                wBlockError(`[wBlock] Failed to inject userscript ${script && script.name ? script.name : 'unknown'}:`, error);
            });
        }

        async injectSingleScriptAsync(script, generation = this.documentStartRequestGeneration) {
            if (generation !== this.documentStartRequestGeneration) return;
            // Check @noframes directive - skip if in iframe
            if (script.noframes && window !== window.top) {
                wBlockLog(`[wBlock] Skipping ${script.name} in iframe due to @noframes directive`);
                return;
            }
            // Userstyles bypass the userscript machinery entirely: the payload is
            // ready-to-apply CSS, so inject a <style> element and stop.
            if (script.kind === 'style') {
                const executionKey = this.scriptExecutionKey(script);
                if (this.injectedScripts.has(executionKey) || this.injectingScripts.get(executionKey) === generation) {
                    return;
                }
                this.injectingScripts.set(executionKey, generation);
                try {
                    const fullStyle = await this.ensureScriptPayload(script);
                    if (generation !== this.documentStartRequestGeneration) return;
                    const css = typeof fullStyle.content === 'string' ? fullStyle.content : '';
                    if (css.length > 0) {
                        await this.waitForDocumentRoot();
                        if (generation !== this.documentStartRequestGeneration) return;
                        const validated = await this.validateScriptForExecution(fullStyle);
                        if (generation !== this.documentStartRequestGeneration || !validated) return;
                        this.injectStyleElement(fullStyle, css);
                        if (generation === this.documentStartRequestGeneration) {
                            this.injectedScripts.add(executionKey);
                        }
                    }
                } finally {
                    if (this.injectingScripts.get(executionKey) === generation) {
                        this.injectingScripts.delete(executionKey);
                    }
                }
                return;
            }

            if (!this.shouldRunScript(script)) {
                // Add to pending scripts if it's not ready to run
                if (!this.pendingScripts.some(s => s.name === script.name)) {
                    wBlockLog(`[wBlock] Adding ${script.name} to pending scripts list.`);
                    this.pendingScripts.push(script);
                }
                return;
            }

            const executionKey = this.scriptExecutionKey(script);
            this.injectingScripts.set(executionKey, generation);
            const warmStart = script.__wblockWarmStart === true;
            if (warmStart) {
                // The warm-start cache belongs to the page. Strip every bridge field
                // before the first await. Cached page code receives no native capability.
                delete script.storageBridgeId;
                delete script.menuBridgeId;
                delete script.xhrBridgeId;
                delete script.portBridgeId;
                delete script.storageSnapshot;
            }
            try {
                const fullScript = await this.ensureScriptPayload(script);
                if (generation !== this.documentStartRequestGeneration) return;
                if (warmStart) fullScript.storageSnapshot = {};
                if (!warmStart && fullScript.id && !fullScript.menuBridgeId) {
                    fullScript.menuBridgeId = this.generateSecret('gmmenu');
                }
                // Token used to namespace this script's GM runtime ports so other
                // page scripts cannot guess the channel name and spoof port
                // messages (see channelNameForPort in the wrapper).
                if (!warmStart && !fullScript.portBridgeId) {
                    fullScript.portBridgeId = this.generateSecret('gmport');
                }

                const injectInto = requiresIsolatedGM(fullScript) ? 'content' : (fullScript.injectInto || 'page');
                if (injectInto !== 'content') {
                    // No secret, arbitrary storage snapshot or native capability enters MAIN.
                    delete fullScript.storageBridgeId;
                    delete fullScript.xhrBridgeId;
                    delete fullScript.portBridgeId;
                }
                wBlockLog(`[wBlock] Injecting userscript: ${fullScript.name} (mode: ${injectInto})`);

                // Page-world injection requires an element parent. Start fetching
                // document-start scripts immediately, but wait only until <html>
                // exists—not until DOMContentLoaded—before appending the wrapper.
                if (injectInto !== 'content') {
                    await this.waitForDocumentRoot();
                    if (generation !== this.documentStartRequestGeneration) return;
                    if (fullScript.runAt === 'document-start' && !getCspNonce()) {
                        if (fullScript.wblockWaitForCspNonce || !this.inlinePageScriptsCanRun()) {
                            await this.waitForCspNonce();
                        }
                    }
                }

                if (generation !== this.documentStartRequestGeneration) return;
                // Cached code must obey current site permissions before it runs, too.
                const validated = await this.validateScriptForExecution(fullScript);
                if (generation !== this.documentStartRequestGeneration || !validated) return;
                this.removeDarkReaderGuard(fullScript);
                if (!warmStart && injectInto !== 'content' && isTubeCleanerPageScript(fullScript)) {
                    this.tubeCleanerSettingsScript = fullScript;
                }
                if (!warmStart && injectInto !== 'content' && isPopupBlockerPageScript(fullScript)) {
                    this.popupBlockerScript = fullScript;
                    this.popupBlockerState = popupBlockerStorage(fullScript.storageSnapshot);
                }
                if (injectInto === 'content') {
                    // Execute directly in content script context (CSP-safe)
                    this.injectInContentContext(fullScript);
                } else if (injectInto === 'auto') {
                    // Try page context first, fall back to content if CSP blocks
                    if (!this.tryInjectInPageContext(fullScript)) {
                        wBlockLog(`[wBlock] Page injection blocked (likely CSP), falling back to content context for ${fullScript.name}`);
                        this.injectInContentContext(fullScript);
                    }
                } else {
                    // Default: page context
                    this.injectInPageContext(fullScript);
                }

                if (generation === this.documentStartRequestGeneration) {
                    this.injectedScripts.add(executionKey);
                    wBlockLog(`[wBlock] Successfully injected and registered userscript: ${fullScript.name} at ${fullScript.runAt || 'document-end'}`);
                }
            } finally {
                if (this.injectingScripts.get(executionKey) === generation) {
                    this.injectingScripts.delete(executionKey);
                }
            }
        }

        // Page context injection (default behavior - via <script> tag)
        injectInPageContext(script) {
            if (isSandboxedWithoutScripts()) {
                wBlockLog(`[wBlock] Skipping page-context injection in sandboxed frame (no allow-scripts): ${script.name}`);
                return;
            }
            const scriptElement = document.createElement('script');
            scriptElement.textContent = this.wrapUserScript(script, 'page');
            scriptElement.setAttribute('data-userscript', script.name);
            scriptElement.setAttribute('type', 'text/javascript');
            const nonce = getCspNonce();
            if (nonce) {
                scriptElement.nonce = nonce;
            }
            if (script.menuBridgeId) {
                this.attachPageMenuCommandBridge(scriptElement, script);
            }
            (document.head || document.documentElement).appendChild(scriptElement);
            scriptElement.remove();
            wBlockLog(`[wBlock] Injected ${script.name} in page context via <script> tag`);
        }

        // Try page context, return false if CSP blocks
        tryInjectInPageContext(script) {
            try {
                if (isSandboxedWithoutScripts()) {
                    return false;
                }
                // Test if we can inject a script tag (CSP check).
                // NOTE: In WebExtension/Safari extension isolated worlds, `window` is not shared
                // with the page context, so use a DOM side-effect to detect execution.
                const testElement = document.createElement('script');
                const testId = `__wblock_csp_test_${Date.now()}`;
                testElement.textContent = `try{document.documentElement && document.documentElement.setAttribute('${testId}','1');}catch(e){}`;
                const nonce = getCspNonce();
                if (nonce) {
                    testElement.nonce = nonce;
                }
                (document.head || document.documentElement).appendChild(testElement);

                // Check if the script actually executed
                const executed = document.documentElement && document.documentElement.getAttribute(testId) === '1';
                testElement.remove();
                try { document.documentElement && document.documentElement.removeAttribute(testId); } catch (e) {}

                if (executed) {
                    this.injectInPageContext(script);
                    return true;
                }
                return false;
            } catch (e) {
                wBlockLog(`[wBlock] CSP test failed for ${script.name}: ${e.message}`);
                return false;
            }
        }

        // Content script context injection (CSP-safe, runs in extension context)
        injectInContentContext(script) {
            try {
                const wrappedCode = this.wrapUserScript(script, 'content');
                // Execute directly in the content script context using Function constructor
                const executeScript = new Function(wrappedCode);
                executeScript();
                wBlockLog(`[wBlock] Injected ${script.name} in content context (CSP-safe)`);
            } catch (error) {
                wBlockError(`[wBlock] Content context execution failed for ${script.name}:`, error);
            }
        }

        // Userstyle injection: CSS applied through a <style> element. Works under any
        // CSP (style-src does not block extension-inserted inline styles in Safari
        // content-script worlds the way script-src blocks scripts) and applies before
        // first paint when injected at document_start.
        injectStyleElement(style, css) {
            const styleElement = document.createElement('style');
            styleElement.textContent = css;
            styleElement.setAttribute('data-wblock-userstyle', style.name || '');
            (document.head || document.documentElement).appendChild(styleElement);
            wBlockLog(`[wBlock] Injected userstyle ${style.name} (${css.length} chars)`);
            return styleElement;
        }

        shouldRunScript(script) {
            const runAt = script.runAt || 'document-end'; 
            const readyState = document.readyState;
            let shouldRun = false;

            wBlockLog(`[wBlock] Checking shouldRunScript for ${script.name}: runAt='${runAt}', document.readyState='${readyState}'`);

            switch (runAt) {
                case 'document-start':
                    shouldRun = true; 
                    break;
                case 'document-end':
                    shouldRun = readyState === 'interactive' || readyState === 'complete';
                    break;
                case 'document-body':
                    shouldRun = !!document.body;
                    break;
                case 'document-idle':
                    shouldRun = readyState === 'complete';
                    break;
                default:
                    wBlockWarn(`[wBlock] Unknown runAt value: '${runAt}' for script ${script.name}. Defaulting to document-end behavior.`);
                    shouldRun = readyState === 'interactive' || readyState === 'complete';
                    break;
            }
            
            if (!shouldRun) {
                wBlockLog(`[wBlock] Userscript ${script.name} will NOT run at this time (runAt: '${runAt}', readyState: '${readyState}').`);
            } else {
                wBlockLog(`[wBlock] Userscript ${script.name} WILL run at this time (runAt: '${runAt}', readyState: '${readyState}').`);
            }
            return shouldRun;
        }

        wrapUserScript(script, context = 'page') {
            // Serialize resources and shared storage state for injection
            const resourcesJSON = script.resources ? JSON.stringify(script.resources) : '{}';
            const isContentContext = context === 'content';
            const storageSnapshotJSON = JSON.stringify(isContentContext ? script.storageSnapshot || {} : pageStorageSnapshot(script));
            const exposePageGlobals = !isContentContext && isPopupBlockerPageScript(script);
            const exposeGMGlobals = isContentContext || exposePageGlobals;
            const exposeGMGlobalsPrefix = exposePageGlobals
                ? `if (location.hostname === 'popupblocker.adguard.com' && location.pathname.endsWith('/options.html')) {`
                : '';
            const exposeGMGlobalsSuffix = exposePageGlobals ? '}' : '';

            // In content context, unsafeWindow is just the content script's window (no page JS access)
            // In page context, we try to access the real page window
            // As in Tampermonkey, a sandboxed script sees unsafeWindow only when it grants it.
            // Scripts such as KISS Translator feature-detect it and otherwise bridge to the
            // page themselves; an isolated-window stand-in silently breaks that bridge.
            const grants = (script.grant || []).map(grant => String(grant).toLowerCase());
            const definesUnsafeWindow = !isContentContext || grants.includes('unsafewindow')
                || grants.every(grant => grant === 'none');
            const unsafeWindowCode = isContentContext
                ? (definesUnsafeWindow ? `// Content context: unsafeWindow is the content script's window (no page JS access)
    const unsafeWindow = window;` : '')
                : `// Get reference to the actual page window (not the isolated extension context)
    // This is the real unsafeWindow that can access page variables
    const unsafeWindow = (function() {
        try {
            // Try to access the page's window through various methods
            if (typeof window.wrappedJSObject !== 'undefined') {
                return window.wrappedJSObject;
            }
            // In Safari, the window object we have IS the page context when injected via <script> tag
            return window;
        } catch (e) {
            wBlockWarn('[wBlock] Could not access page context, falling back to regular window');
            return window;
        }
    })();`;

            const strictModeDirective = isContentContext ? "'use strict';" : '';

            return `
// wBlock Userscript Wrapper for: ${escapeForJS(script.name)} (${context} context)
(function() {
    ${strictModeDirective}
    // Debug logging helpers - wrapper-private names avoid collisions with userscript globals.
    var __wBlockDebugLogging = ${WBLOCK_DEBUG_LOGGING};
    var wBlockLog = (...args) => {
        if (__wBlockDebugLogging) {
            console.log(...args);
        }
    };

    var wBlockWarn = (...args) => {
        if (__wBlockDebugLogging) {
            console.warn(...args);
        }
    };

    var wBlockError = (...args) => {
        console.error(...args);
    };

    wBlockLog('[wBlock UserScript] Executing: ${escapeForJS(script.name)} in ${context} context');

    // Store resources for this script
    const scriptResources = ${resourcesJSON};

    // Storage change listeners registry
    const storageListeners = new Map(); // key -> Map(listenerId, callback)
    const pendingStorageRequests = new Map(); // requestId -> { onFailure, timeoutId }
    const menuCommandCallbacks = new Map(); // commandId -> callback
    let listenerIdCounter = 0;
    const storageBridgeId = '${escapeForJS(script.storageBridgeId || '')}';
    const menuBridgeId = '${escapeForJS(script.menuBridgeId || '')}';
    const xhrBridgeId = '${escapeForJS(script.xhrBridgeId || '')}';
    const portBridgeId = '${escapeForJS(script.portBridgeId || '')}';
    const pageMenuBridgeElement = ${isContentContext ? 'null' : 'document.currentScript'};
    const contentMenuBridge = ${isContentContext ? 'window.__wBlockMenuCommandBridge' : 'null'};
    const scriptStorageState = Object.assign({}, ${storageSnapshotJSON});
    const runtimePorts = new Map(); // portName -> Set(port)

    const makeRuntimeEvent = () => {
        const listeners = new Set();
        return {
            addListener: function(listener) {
                if (typeof listener === 'function') listeners.add(listener);
            },
            removeListener: function(listener) {
                listeners.delete(listener);
            },
            hasListener: function(listener) {
                return listeners.has(listener);
            },
            dispatch: function(...args) {
                listeners.forEach(listener => {
                    try { listener(...args); }
                    catch (error) { wBlockError('[wBlock] Runtime port listener error:', error); }
                });
            }
        };
    };

    // Map a userscript-facing port name to the per-script wire channel name.
    // The background treats this string opaquely and echoes it back when
    // delivering port messages, so a page script that does not know
    // portBridgeId cannot address (or spoof messages to) this script's ports.
    const channelNameForPort = (userPortName) => {
        return portBridgeId && userPortName ? portBridgeId + '::' + userPortName : userPortName;
    };

    const createRuntimePort = (connectInfo) => {
        // Quarantined warm starts have no runtime/native port token at all.
        if (!portBridgeId) {
            return {
                name: typeof connectInfo === 'string' ? connectInfo : (connectInfo && connectInfo.name) || '',
                onMessage: makeRuntimeEvent(), onDisconnect: makeRuntimeEvent(),
                postMessage: function() {}, disconnect: function() {}
            };
        }
        const userPortName = typeof connectInfo === 'string'
            ? connectInfo
            : (connectInfo && typeof connectInfo.name === 'string' ? connectInfo.name : '');
        const channelName = channelNameForPort(userPortName);
        const onMessage = makeRuntimeEvent();
        const onDisconnect = makeRuntimeEvent();
        const port = {
            name: userPortName,
            onMessage: onMessage,
            onDisconnect: onDisconnect,
            postMessage: function(message) {
                // These streaming ports are receive-only; page events are never a transport.
            },
            disconnect: function() {
                const ports = runtimePorts.get(channelName);
                if (ports) {
                    ports.delete(port);
                    if (ports.size === 0) runtimePorts.delete(channelName);
                }
                onDisconnect.dispatch(port);
            }
        };
        if (!runtimePorts.has(channelName)) runtimePorts.set(channelName, new Set());
        runtimePorts.get(channelName).add(port);
        return port;
    };

    const deliverRuntimePortMessage = (portName, message) => {
        const ports = runtimePorts.get(portName);
        if (!ports || ports.size === 0) return false;
        ports.forEach(port => port.onMessage.dispatch(message, port));
        return true;
    };

    ${isContentContext ? `
    if (typeof browser !== 'undefined' && browser.runtime && browser.runtime.onMessage) {
        const onPortMessage = (data) => {
            if (!data || data.type !== 'wblock:gm-port-message') return;
            deliverRuntimePortMessage(data.portName || '', data.message);
        };
        browser.runtime.onMessage.addListener(onPortMessage);
        window.addEventListener('pagehide', () => browser.runtime.onMessage.removeListener(onPortMessage));
        window.addEventListener('pageshow', (e) => { if (e.persisted) browser.runtime.onMessage.addListener(onPortMessage); });
    }
    ` : ''}

    const resolveUserscriptRequestURL = (url) => {
        try {
            return new URL(String(url || ''), location.href).href;
        } catch (_error) {
            return url;
        }
    };

    const patchRuntimeConnect = (api) => {
        if (!api || typeof api !== 'object') return api;
        if (!api.runtime || typeof api.runtime !== 'object') api.runtime = {};
        if (typeof api.runtime.connect !== 'function') {
            api.runtime.connect = function(connectInfo) { return createRuntimePort(connectInfo); };
        }
        return api;
    };

    try {
        let immersiveBrowserAPI = patchRuntimeConnect(globalThis.immersiveTranslateBrowserAPI);
        Object.defineProperty(globalThis, 'immersiveTranslateBrowserAPI', {
            configurable: true,
            get: function() { return immersiveBrowserAPI; },
            set: function(value) { immersiveBrowserAPI = patchRuntimeConnect(value); }
        });
    } catch (error) {
        wBlockWarn('[wBlock] Failed to install runtime port shim:', error);
    }

    const parseStoredValue = (rawValue) => {
        if (rawValue === null || typeof rawValue === 'undefined') {
            return undefined;
        }
        try {
            return JSON.parse(rawValue);
        } catch (error) {
            wBlockWarn('[wBlock] Failed to parse stored GM value, returning raw string:', error);
            return rawValue;
        }
    };

    const serializeStoredValue = (value) => {
        const serialized = JSON.stringify(value);
        return typeof serialized === 'undefined' ? 'undefined' : serialized;
    };

    const notifyStorageListeners = (key, oldValue, newValue, remote) => {
        const listeners = storageListeners.get(key);
        if (!listeners || listeners.size === 0) {
            return;
        }

        listeners.forEach((callback) => {
            try {
                callback(key, oldValue, newValue, remote);
            } catch (error) {
                wBlockError('[wBlock] Storage listener error:', error);
            }
        });
    };

    const postMenuCommandResult = (requestId, success, error) => {
        if (!pageMenuBridgeElement || typeof requestId !== 'string' || requestId.length === 0) return;
        pageMenuBridgeElement.dispatchEvent(new CustomEvent('wblock-gm-menu-invoke-result', {
            detail: {
                bridgeId: menuBridgeId,
                requestId: requestId,
                success: success !== false,
                error: typeof error === 'string' ? error : ''
            }
        }));
    };

    const normalizeMenuCommandOptions = (accessKey) => {
        if (typeof accessKey === 'string') {
            return { accessKey: accessKey, title: '' };
        }
        if (accessKey && typeof accessKey === 'object') {
            return {
                accessKey: typeof accessKey.accessKey === 'string' ? accessKey.accessKey : '',
                title: typeof accessKey.title === 'string' ? accessKey.title : ''
            };
        }
        return { accessKey: '', title: '' };
    };

    const publishMenuCommand = (kind, commandId, details, callback) => {
        if (!menuBridgeId || typeof commandId !== 'string' || commandId.length === 0) {
            return;
        }

        const normalizedDetails = {
            caption: typeof details.caption === 'string' ? details.caption : String(details.caption ?? ''),
            title: typeof details.title === 'string' ? details.title : '',
            accessKey: typeof details.accessKey === 'string' ? details.accessKey : '',
            scriptName: '${escapeForJS(script.name || 'Unknown Script')}'
        };

        if (contentMenuBridge && kind === 'register' && typeof contentMenuBridge.registerMenuCommand === 'function') {
            contentMenuBridge.registerMenuCommand(menuBridgeId, commandId, normalizedDetails, callback);
            return;
        }

        if (contentMenuBridge && kind === 'unregister' && typeof contentMenuBridge.unregisterMenuCommand === 'function') {
            contentMenuBridge.unregisterMenuCommand(menuBridgeId, commandId);
            return;
        }

        if (!pageMenuBridgeElement) {
            return;
        }

        pageMenuBridgeElement.dispatchEvent(new CustomEvent(
            kind === 'register' ? 'wblock-gm-menu-register' : 'wblock-gm-menu-unregister',
            {
                detail: kind === 'register'
                    ? { bridgeId: menuBridgeId, commandId: commandId, ...normalizedDetails }
                    : { bridgeId: menuBridgeId, commandId: commandId }
            }
        ));
    };

    ${isContentContext ? `` : `
    if (pageMenuBridgeElement) {
        pageMenuBridgeElement.addEventListener('wblock-gm-menu-invoke', (event) => {
            const detail = event && event.detail ? event.detail : {};
            if (detail.bridgeId !== menuBridgeId || typeof detail.commandId !== 'string') return;

            const callback = menuCommandCallbacks.get(detail.commandId);
            if (!callback) {
                postMenuCommandResult(detail.requestId, false, 'Menu command not found');
                return;
            }

            try {
                Promise.resolve(callback())
                    .then(() => postMenuCommandResult(detail.requestId, true, ''))
                    .catch((error) => {
                        postMenuCommandResult(
                            detail.requestId,
                            false,
                            error && error.message ? error.message : String(error)
                        );
                    });
            } catch (error) {
                postMenuCommandResult(
                    detail.requestId,
                    false,
                    error && error.message ? error.message : String(error)
                );
            }
        });
    }
    `}

    ${isContentContext ? `` : `
    window.addEventListener('message', (event) => {
        if (event.source !== window) return;
        const data = event.data;
        if (!data || data.type !== 'wblock-gm-storage-result' || typeof data.requestId !== 'string') return;

        const pending = pendingStorageRequests.get(data.requestId);
        if (!pending) return;
        pendingStorageRequests.delete(data.requestId);
        clearTimeout(pending.timeoutId);

        if (data.success === false && typeof pending.onFailure === 'function') {
            pending.onFailure(data.error || 'Failed to persist GM storage change');
        }
    });
    `}

    const persistStorageChange = (kind, key, rawValue, onFailure) => {
        if (!key) {
            if (typeof onFailure === 'function') {
                onFailure('Missing GM storage key');
            }
            return;
        }

        ${isContentContext ? `
        const message = {
            action: kind === 'set' ? 'setUserScriptStorageValue' : 'deleteUserScriptStorageValue',
            scriptId: '${escapeForJS(script.id || '')}',
            key: key
        };
        if (kind === 'set') {
            message.rawValue = rawValue;
        }

        if (typeof browser !== 'undefined' && browser.runtime && browser.runtime.sendMessage) {
            browser.runtime.sendMessage(message)
                .then((result) => {
                    if ((!result || result.ok === false) && typeof onFailure === 'function') {
                        onFailure((result && result.error) || 'Failed to persist GM storage change');
                    }
                })
                .catch((error) => {
                    if (typeof onFailure === 'function') {
                        onFailure(error && error.message ? error.message : String(error));
                    }
                });
            return;
        }

        if (typeof onFailure === 'function') {
            onFailure('No messaging API available for GM storage persistence');
        }
        ` : `
        ${isTubeCleanerPageScript(script) ? `
        if (kind === 'set' && key === 'wblock.tubeCleaner.sponsorBlock') {
            try { window.postMessage({ type: 'wblock:tube-preferences', settings: JSON.parse(rawValue) }, '*'); }
            catch (_) { /* Invalid preference updates have no native effect. */ }
            return;
        }
        ` : ''}
        ${isPopupBlockerPageScript(script) ? `
        // The content world decides what persists; deletes only run in migrations.
        if (kind === 'set') window.postMessage({ type: 'wblock:popup-blocker-storage', key, rawValue }, '*');
        return;
        ` : ''}
        if (!storageBridgeId) {
            if (typeof onFailure === 'function') {
                onFailure('Missing GM storage bridge identifier');
            }
            return;
        }

        const requestId = 'gmstorage-' + Date.now() + '-' + Math.random().toString(36).slice(2);
        if (typeof onFailure === 'function') {
            const timeoutId = setTimeout(() => {
                const pending = pendingStorageRequests.get(requestId);
                if (!pending) return;
                pendingStorageRequests.delete(requestId);
                pending.onFailure('GM storage persistence timed out');
            }, 15000);
            pendingStorageRequests.set(requestId, { onFailure, timeoutId });
        }

        const message = {
            type: kind === 'set' ? 'wblock-gm-storage-set' : 'wblock-gm-storage-delete',
            bridgeId: storageBridgeId,
            key: key,
            requestId: requestId
        };
        if (kind === 'set') {
            message.rawValue = rawValue;
        }
        window.postMessage(message, '*');
        `}
    };

    const inferResourceMimeType = (resourceName, resourceValue) => {
        const lowerName = String(resourceName || '').toLowerCase();
        if (lowerName.endsWith('.css')) return 'text/css';
        if (lowerName.endsWith('.js') || lowerName.endsWith('.mjs')) return 'text/javascript';
        if (lowerName.endsWith('.json')) return 'application/json';
        if (lowerName.endsWith('.xml')) return 'application/xml';
        if (lowerName.endsWith('.svg')) return 'image/svg+xml';
        if (lowerName.endsWith('.png')) return 'image/png';
        if (lowerName.endsWith('.jpg') || lowerName.endsWith('.jpeg')) return 'image/jpeg';
        if (lowerName.endsWith('.gif')) return 'image/gif';
        if (lowerName.endsWith('.webp')) return 'image/webp';
        if (lowerName.endsWith('.mp3')) return 'audio/mpeg';
        if (lowerName.endsWith('.ogg')) return 'audio/ogg';
        if (lowerName.endsWith('.wav')) return 'audio/wav';
        if (lowerName.endsWith('.woff2')) return 'font/woff2';
        if (lowerName.endsWith('.woff')) return 'font/woff';
        if (lowerName.endsWith('.ttf')) return 'font/ttf';

        const trimmedValue = typeof resourceValue === 'string' ? resourceValue.trim() : '';
        if (!trimmedValue) return 'text/plain';
        if (
            (trimmedValue.startsWith('{') && trimmedValue.endsWith('}'))
            || (trimmedValue.startsWith('[') && trimmedValue.endsWith(']'))
        ) {
            return 'application/json';
        }
        if (trimmedValue.startsWith('<svg')) {
            return 'image/svg+xml';
        }
        if (/(^|\\n)\s*(?:const|let|var|function|class|export|import)\b/.test(trimmedValue) || trimmedValue.includes('=>')) {
            return 'text/javascript';
        }
        if (/(^|\\n)\s*[@.#a-zA-Z0-9_-]+\s*\{/.test(trimmedValue) || /:\s*[^;]+;/.test(trimmedValue)) {
            return 'text/css';
        }
        return 'text/plain';
    };

    const isProbablyTextMimeType = (mimeType) => {
        const normalized = String(mimeType || '').toLowerCase();
        return normalized.startsWith('text/')
            || normalized.includes('json')
            || normalized.includes('javascript')
            || normalized.includes('xml')
            || normalized === 'image/svg+xml';
    };

    const decodeDataUrlText = (dataUrl) => {
        const match = String(dataUrl || '').match(/^data:([^;,]+)?(?:;charset=[^;,]+)?(;base64)?,([\s\S]*)$/i);
        if (!match) {
            return undefined;
        }

        const mimeType = match[1] || 'text/plain';
        if (!isProbablyTextMimeType(mimeType)) {
            return undefined;
        }

        try {
            if (match[2]) {
                const binary = atob(match[3] || '');
                const bytes = new Uint8Array(binary.length);
                for (let i = 0; i < binary.length; i++) {
                    bytes[i] = binary.charCodeAt(i);
                }
                return new TextDecoder('utf-8').decode(bytes);
            }
            return decodeURIComponent(match[3] || '');
        } catch (error) {
            wBlockWarn('[wBlock] Failed to decode data URL resource text:', error);
            return undefined;
        }
    };

    const resolveResourceValue = (resourceName) => {
        if (!scriptResources || !Object.prototype.hasOwnProperty.call(scriptResources, resourceName)) {
            return undefined;
        }
        return scriptResources[resourceName];
    };

    const makeResourceURL = (resourceName) => {
        const resourceValue = resolveResourceValue(resourceName);
        if (typeof resourceValue !== 'string' || resourceValue.length === 0) {
            return undefined;
        }

        if (/^(data:|blob:|https?:)/i.test(resourceValue)) {
            return resourceValue;
        }

        const mimeType = inferResourceMimeType(resourceName, resourceValue);
        return 'data:' + mimeType + ';charset=utf-8,' + encodeURIComponent(resourceValue);
    };

    ${unsafeWindowCode}

    const GM = {
        info: {
            script: {
                name: '${escapeForJS(script.name || 'Unknown Script')}',
                version: '${escapeForJS(script.version || '1.0.0')}',
                description: '${escapeForJS(script.description || '')}',
                namespace: '${escapeForJS(script.namespace || 'wblock')}',
                updateURL: '${escapeForJS(script.updateURL || '')}',
                downloadURL: '${escapeForJS(script.downloadURL || '')}'
            },
            scriptUpdateURL: '${escapeForJS(script.updateURL || '')}',
            scriptDownloadURL: '${escapeForJS(script.downloadURL || '')}',
            scriptHandler: 'wBlock Injector',
            version: '0.2.0'
        },
        log: function(...args) { wBlockLog('[UserScript:${escapeForJS(script.name)}]', ...args); },

        // Greasemonkey API implementations backed by shared per-userscript storage
        getValue: function(key, defaultValue) {
            try {
                if (Object.prototype.hasOwnProperty.call(scriptStorageState, key)) {
                    return parseStoredValue(scriptStorageState[key]);
                }
                return defaultValue;
            } catch (e) {
                wBlockWarn('[wBlock] Failed to get value for key:', key, e);
                return defaultValue;
            }
        },

        setValue: function(key, value) {
            try {
                const hadValue = Object.prototype.hasOwnProperty.call(scriptStorageState, key);
                const previousRawValue = hadValue ? scriptStorageState[key] : undefined;
                const oldValue = hadValue ? parseStoredValue(previousRawValue) : undefined;
                const rawValue = serializeStoredValue(value);
                scriptStorageState[key] = rawValue;
                notifyStorageListeners(key, oldValue, value, false);
                persistStorageChange('set', key, rawValue, (error) => {
                    if (hadValue) {
                        scriptStorageState[key] = previousRawValue;
                    } else {
                        delete scriptStorageState[key];
                    }
                    wBlockWarn('[wBlock] Failed to persist value for key:', key, error);
                    notifyStorageListeners(key, value, oldValue, true);
                });
            } catch (e) {
                wBlockWarn('[wBlock] Failed to save value for key:', key, e);
            }
        },

        deleteValue: function(key) {
            try {
                if (!Object.prototype.hasOwnProperty.call(scriptStorageState, key)) {
                    return;
                }
                const previousRawValue = scriptStorageState[key];
                const oldValue = parseStoredValue(previousRawValue);
                delete scriptStorageState[key];
                notifyStorageListeners(key, oldValue, undefined, false);
                persistStorageChange('delete', key, undefined, (error) => {
                    scriptStorageState[key] = previousRawValue;
                    wBlockWarn('[wBlock] Failed to delete value for key:', key, error);
                    notifyStorageListeners(key, undefined, oldValue, true);
                });
            } catch (e) {
                wBlockWarn('[wBlock] Failed to delete value for key:', key, e);
            }
        },

        listValues: function() {
            try {
                return Object.keys(scriptStorageState);
            } catch (e) {
                wBlockWarn('[wBlock] Failed to list values:', e);
                return [];
            }
        },

        getResourceURL: function(resourceName) {
            const resolvedURL = makeResourceURL(resourceName);
            if (resolvedURL) {
                return resolvedURL;
            }
            wBlockWarn('[wBlock] Resource URL not found:', resourceName);
            return undefined;
        },

        getResourceUrl: function(resourceName) {
            return GM.getResourceURL(resourceName);
        },

        getResourceText: function(resourceName) {
            wBlockLog('[wBlock] GM_getResourceText called with:', resourceName);
            const resourceValue = resolveResourceValue(resourceName);
            if (typeof resourceValue === 'string') {
                if (/^data:/i.test(resourceValue)) {
                    return decodeDataUrlText(resourceValue);
                }
                return resourceValue;
            }
            wBlockWarn('[wBlock] Resource not found:', resourceName);
            return undefined;
        },

        addElement: function(parentOrTagName, tagNameOrAttributes, maybeAttributes) {
            try {
                let parent = null;
                let tagName = parentOrTagName;
                let attributes = tagNameOrAttributes;

                if (parentOrTagName && typeof parentOrTagName.appendChild === 'function') {
                    parent = parentOrTagName;
                    tagName = tagNameOrAttributes;
                    attributes = maybeAttributes;
                }

                wBlockLog('[wBlock] GM_addElement called:', tagName, attributes);
                const element = document.createElement(tagName);

                if (attributes) {
                    for (const [key, value] of Object.entries(attributes)) {
                        if (key === 'textContent') {
                            element.textContent = value;
                        } else if (key === 'innerHTML') {
                            element.innerHTML = value;
                        } else if (key === 'parentNode') {
                            continue;
                        } else {
                            element.setAttribute(key, value);
                        }
                    }
                }

                parent = parent || (attributes && attributes.parentNode ? attributes.parentNode : (document.head || document.documentElement));
                if (parent) {
                    parent.appendChild(element);
                }

                return element;
            } catch (e) {
                wBlockError('[wBlock] GM_addElement failed:', e);
                return null;
            }
        },

        addValueChangeListener: function(key, callback) {
            const listenerId = ++listenerIdCounter;
            wBlockLog('[wBlock] GM.addValueChangeListener:', key, listenerId);

            if (!storageListeners.has(key)) {
                storageListeners.set(key, new Map());
            }
            storageListeners.get(key).set(listenerId, callback);

            return listenerId;
        },

        removeValueChangeListener: function(listenerId) {
            wBlockLog('[wBlock] GM.removeValueChangeListener:', listenerId);

            for (const [key, listeners] of storageListeners.entries()) {
                if (listeners.has(listenerId)) {
                    listeners.delete(listenerId);
                    if (listeners.size === 0) {
                        storageListeners.delete(key);
                    }
                    return;
                }
            }
        },

        registerMenuCommand: function(caption, callback, accessKey) {
            wBlockLog('[wBlock] GM.registerMenuCommand called:', caption);
            if (typeof callback !== 'function') {
                wBlockWarn('[wBlock] Ignoring GM.registerMenuCommand with non-function callback:', caption);
                return null;
            }

            const menuCommandId = 'menu-' + (++listenerIdCounter);
            const normalizedCaption = typeof caption === 'string' ? caption : String(caption ?? '');
            const options = normalizeMenuCommandOptions(accessKey);
            menuCommandCallbacks.set(menuCommandId, callback);
            publishMenuCommand('register', menuCommandId, {
                caption: normalizedCaption,
                title: options.title,
                accessKey: options.accessKey
            }, callback);
            return menuCommandId;
        },

        unregisterMenuCommand: function(menuCommandId) {
            wBlockLog('[wBlock] GM.unregisterMenuCommand called:', menuCommandId);
            if (!menuCommandCallbacks.has(menuCommandId)) {
                return;
            }
            menuCommandCallbacks.delete(menuCommandId);
            publishMenuCommand('unregister', menuCommandId, {}, null);
        },

        addStyle: function(css) {
            try {
                const style = document.createElement('style');
                style.textContent = css;
                (document.head || document.documentElement).appendChild(style);
                return style;
            } catch (e) {
                wBlockError('[wBlock] GM.addStyle failed:', e);
                return null;
            }
        },

        setClipboard: function(data, info, callback) {
            const text = typeof data === 'string' ? data : String(data ?? '');
            const finish = () => {
                if (typeof callback === 'function') {
                    callback();
                }
            };

            const fallbackCopy = () => {
                const textarea = document.createElement('textarea');
                textarea.value = text;
                textarea.setAttribute('readonly', 'readonly');
                textarea.style.position = 'fixed';
                textarea.style.opacity = '0';
                (document.body || document.documentElement).appendChild(textarea);
                if (typeof textarea.select === 'function') {
                    textarea.select();
                }
                if (typeof textarea.setSelectionRange === 'function') {
                    textarea.setSelectionRange(0, text.length);
                }
                if (typeof document.execCommand === 'function') {
                    document.execCommand('copy');
                }
                textarea.remove();
                finish();
            };

            if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
                return navigator.clipboard.writeText(text)
                    .then(() => finish())
                    .catch((error) => {
                        wBlockWarn('[wBlock] navigator.clipboard.writeText failed, falling back:', error);
                        fallbackCopy();
                    });
            }

            fallbackCopy();
            return Promise.resolve();
        },

        openInTab: function(url, options) {
            const openInBackground = options && options.active === false;
            const newWindow = window.open(url, '_blank');
            if (!openInBackground && newWindow) {
                newWindow.focus();
            }
            return newWindow;
        },

        notification: function(options) {
            wBlockLog('[wBlock] GM_notification called with:', options);
            // Basic notification implementation
            if (typeof options === 'string') {
                wBlockLog('[wBlock] Notification:', options);
            } else if (options && options.text) {
                wBlockLog('[wBlock] Notification:', options.text);
            }
        },

        download: function(details, name) {
            const normalized = typeof details === 'string'
                ? { url: details, name: name }
                : (details || {});
            const downloadURL = normalized.url || normalized.href;
            const fileName = normalized.name || normalized.filename || name || '';

            if (!downloadURL) {
                const error = new Error('GM_download requires a URL');
                if (typeof normalized.onerror === 'function') {
                    normalized.onerror(error);
                }
                throw error;
            }

            const clickDownloadLink = (href, revokeURL) => {
                const link = document.createElement('a');
                link.href = href;
                if (fileName) {
                    link.download = fileName;
                }
                link.rel = 'noopener';
                link.style.display = 'none';
                (document.body || document.documentElement).appendChild(link);
                if (typeof link.click === 'function') {
                    link.click();
                }
                link.remove();
                if (revokeURL && typeof URL !== 'undefined' && typeof URL.revokeObjectURL === 'function') {
                    setTimeout(() => URL.revokeObjectURL(href), 60000);
                }
            };

            if (typeof URL === 'undefined' || typeof URL.createObjectURL !== 'function') {
                clickDownloadLink(downloadURL, false);
                if (typeof normalized.onload === 'function') {
                    setTimeout(() => normalized.onload(), 0);
                }
                return {
                    abort: function() {
                        wBlockLog('[wBlock] GM_download abort requested for:', downloadURL);
                    }
                };
            }

            const request = __wBlockLegacyGM.xmlhttpRequest({
                method: normalized.method || 'GET',
                url: downloadURL,
                headers: normalized.headers || {},
                data: normalized.data,
                anonymous: normalized.anonymous === true,
                timeout: normalized.timeout || 0,
                responseType: 'blob',
                onloadstart: function(response) {
                    if (typeof normalized.onloadstart === 'function') normalized.onloadstart(response);
                },
                onprogress: function(response) {
                    if (typeof normalized.onprogress === 'function') normalized.onprogress(response);
                },
                onload: function(response) {
                    try {
                        const responseBody = response && response.response;
                        const blob = typeof Blob !== 'undefined' && responseBody instanceof Blob
                            ? responseBody
                            : new Blob([responseBody || response.responseText || '']);
                        const objectURL = URL.createObjectURL(blob);
                        clickDownloadLink(objectURL, true);
                        if (typeof normalized.onload === 'function') {
                            normalized.onload(response);
                        }
                    } catch (error) {
                        if (typeof normalized.onerror === 'function') {
                            normalized.onerror(error);
                        } else {
                            wBlockError('[wBlock] GM_download failed:', error);
                        }
                    }
                },
                onerror: function(response) {
                    if (typeof normalized.onerror === 'function') normalized.onerror(response);
                },
                ontimeout: function(response) {
                    if (typeof normalized.ontimeout === 'function') normalized.ontimeout(response);
                    else if (typeof normalized.onerror === 'function') normalized.onerror(response);
                },
                onabort: function(response) {
                    if (typeof normalized.onabort === 'function') normalized.onabort(response);
                }
            });

            return {
                abort: function() {
                    wBlockLog('[wBlock] GM_download abort requested for:', downloadURL);
                    if (request && typeof request.abort === 'function') {
                        request.abort();
                    }
                }
            };
        },

        xmlhttpRequest: function(details) {
            // GM_xmlhttpRequest routed through the extension's background/native
            // layer to bypass page-level CORS restrictions.
            wBlockLog('[wBlock] GM_xmlhttpRequest called with:', details);

            if (!details || !details.url) {
                wBlockError('[wBlock] GM_xmlhttpRequest: No URL provided');
                return;
            }

            const method = (details.method || 'GET').toUpperCase();
            const requestId = 'gmxhr-' + Date.now() + '-' + Math.random().toString(36).slice(2);

            const normalizeGMResponseHeaders = (headers) => {
                if (typeof headers === 'string') return headers;
                if (!headers || typeof headers !== 'object') return '';
                return Object.entries(headers)
                    .map(([key, value]) => key + ': ' + value)
                    .join('\\r\\n');
            };

            let completed = false;
            let timeoutId = null;

            const clearRequestTimeout = () => {
                if (timeoutId) {
                    clearTimeout(timeoutId);
                    timeoutId = null;
                }
            };

            const normalizeGMResponseType = (responseType) => String(responseType || 'text').trim().toLowerCase();

            const arrayBufferFromBase64 = (base64) => {
                const binary = atob(base64 || '');
                const bytes = new Uint8Array(binary.length);
                for (let i = 0; i < binary.length; i++) {
                    bytes[i] = binary.charCodeAt(i);
                }
                return bytes.buffer;
            };

            const makeTypedResponseBody = (result) => {
                const responseType = normalizeGMResponseType(details.responseType);
                if (!result || typeof result.responseBase64 !== 'string') {
                    return result ? result.response : undefined;
                }

                const arrayBuffer = arrayBufferFromBase64(result.responseBase64);
                if (responseType === 'arraybuffer') {
                    return arrayBuffer;
                }
                if (responseType === 'blob') {
                    const mimeType = typeof result.responseMimeType === 'string' ? result.responseMimeType : '';
                    return typeof Blob !== 'undefined' ? new Blob([arrayBuffer], { type: mimeType }) : arrayBuffer;
                }
                return result.response;
            };

            const makeResponse = (result) => {
                const loaded = Number(result.responseLength || 0);
                const total = Number(result.responseTotal || loaded || 0);
                return {
                    status: result.status,
                    statusText: result.statusText,
                    responseHeaders: normalizeGMResponseHeaders(result.responseHeaders),
                    responseText: typeof result.responseText === 'string' ? result.responseText : '',
                    response: makeTypedResponseBody(result),
                    readyState: 4,
                    loaded: loaded,
                    total: total,
                    lengthComputable: total > 0,
                    finalUrl: result.finalUrl || details.url,
                    responseURL: result.finalUrl || details.url
                };
            };

            const dispatchReadyState = (readyState) => {
                if (typeof details.onreadystatechange === 'function') {
                    details.onreadystatechange({ readyState: readyState, status: 0, statusText: '', finalUrl: details.url, responseURL: details.url });
                }
            };

            const dispatchLoadStart = () => {
                if (typeof details.onloadstart === 'function') {
                    details.onloadstart({ readyState: 1, loaded: 0, total: 0, lengthComputable: false });
                }
                dispatchReadyState(1);
            };

            const onResult = (result) => {
                if (completed) return;
                completed = true;
                clearRequestTimeout();
                const response = makeResponse(result);
                if (typeof details.onprogress === 'function') {
                    details.onprogress(response);
                }
                if (typeof details.onreadystatechange === 'function') {
                    details.onreadystatechange(response);
                }
                if (typeof details.onload === 'function') {
                    details.onload(response);
                }
                if (typeof details.onloadend === 'function') {
                    details.onloadend(response);
                }
            };
            const onFail = (errorMsg, callbackName = 'onerror') => {
                if (completed) return;
                completed = true;
                clearRequestTimeout();
                wBlockError('[wBlock] GM_xmlhttpRequest error:', errorMsg);
                const response = { error: errorMsg, statusText: errorMsg, readyState: 4 };
                if (typeof details[callbackName] === 'function') {
                    details[callbackName](response);
                } else if (callbackName !== 'onerror' && typeof details.onerror === 'function') {
                    details.onerror(response);
                }
                if (typeof details.onloadend === 'function') {
                    details.onloadend(response);
                }
            };

            const requestPayload = {
                scriptId: '${escapeForJS(script.id || '')}',
                url: resolveUserscriptRequestURL(details.url),
                method: method,
                headers: details.headers || {},
                body: details.data || null,
                anonymous: !!details.anonymous,
                responseType: details.responseType || 'text',
                redirect: details.redirect || 'follow',
                timeout: details.timeout || 0,
                overrideMimeType: details.overrideMimeType || '',
                portName: channelNameForPort(details.portName || (details.extra && details.extra.portName) || '')
            };

            const timeoutMs = Number(details.timeout || 0);
            if (Number.isFinite(timeoutMs) && timeoutMs > 0) {
                timeoutId = setTimeout(() => {
                    onFail('GM_xmlhttpRequest timed out', 'ontimeout');
                }, timeoutMs);
            }

            dispatchLoadStart();

            ${isContentContext ? `
            // Content context: send directly via browser.runtime.sendMessage
            (async () => {
                try {
                    if (typeof browser !== 'undefined' && browser.runtime && browser.runtime.sendMessage) {
                        const result = await browser.runtime.sendMessage({
                            action: 'gmXmlhttpRequest', ...requestPayload
                        });
                        if (result && result.error) { onFail(result.error); }
                        else { onResult(result); }
                        return;
                    }
                    onFail('No messaging API available');
                } catch (error) {
                    onFail(error.message || String(error));
                }
            })();

            return { abort: function() { wBlockLog('[wBlock] GM_xmlhttpRequest abort called'); onFail('GM_xmlhttpRequest aborted', 'onabort'); } };
            ` : `
            // MAIN has ordinary page network authority only. CSP and CORS still
            // apply, and no extension credentials, ports or native headers exist.
            const pageAbort = typeof AbortController === 'function' ? new AbortController() : null;
            Promise.resolve().then(() => fetch(requestPayload.url, {
                method, headers: requestPayload.headers, body: requestPayload.body,
                mode: 'cors', credentials: requestPayload.anonymous ? 'omit' : 'same-origin',
                redirect: requestPayload.redirect, signal: pageAbort ? pageAbort.signal : undefined
            })).then(async response => onResult({
                status: response.status, statusText: response.statusText,
                responseText: await response.text(), finalUrl: response.url,
                responseHeaders: Array.from(response.headers.entries()).map(pair => pair.join(': ')).join('\\r\\n')
            })).catch(error => onFail(error.message || String(error)));
            return { abort: function() { if (pageAbort) pageAbort.abort(); onFail('GM_xmlhttpRequest aborted', 'onabort'); } };
            `}
        },

        xmlHttpRequest: function(details) {
            return GM.xmlhttpRequest(details);
        },

        ${definesUnsafeWindow ? 'unsafeWindow: unsafeWindow' : ''}
    };

    const __wBlockLegacyGM = {
        getValue: GM.getValue.bind(GM),
        setValue: GM.setValue.bind(GM),
        deleteValue: GM.deleteValue.bind(GM),
        listValues: GM.listValues.bind(GM),
        getResourceURL: GM.getResourceURL.bind(GM),
        getResourceUrl: GM.getResourceUrl.bind(GM),
        getResourceText: GM.getResourceText.bind(GM),
        xmlhttpRequest: GM.xmlhttpRequest.bind(GM)
    };

    const __wBlockGMRequestPromise = (details) => {
        let requestHandle = null;
        const promise = new Promise((resolve, reject) => {
            const requestDetails = Object.assign({}, details || {});
            const originalOnload = requestDetails.onload;
            const originalOnerror = requestDetails.onerror;
            const originalOntimeout = requestDetails.ontimeout;
            const originalOnabort = requestDetails.onabort;

            requestDetails.onload = function(response) {
                try {
                    if (typeof originalOnload === 'function') originalOnload.call(this, response);
                } finally {
                    resolve(response);
                }
            };
            requestDetails.onerror = function(response) {
                try {
                    if (typeof originalOnerror === 'function') originalOnerror.call(this, response);
                } finally {
                    reject(response);
                }
            };
            requestDetails.ontimeout = function(response) {
                try {
                    if (typeof originalOntimeout === 'function') originalOntimeout.call(this, response);
                } finally {
                    reject(response);
                }
            };
            requestDetails.onabort = function(response) {
                try {
                    if (typeof originalOnabort === 'function') originalOnabort.call(this, response);
                } finally {
                    reject(response);
                }
            };

            requestHandle = __wBlockLegacyGM.xmlhttpRequest(requestDetails);
        });
        promise.abort = function() {
            if (requestHandle && typeof requestHandle.abort === 'function') {
                requestHandle.abort();
            }
        };
        return promise;
    };

    GM.getValue = function(key, defaultValue) {
        return Promise.resolve(__wBlockLegacyGM.getValue(key, defaultValue));
    };
    GM.setValue = function(key, value) {
        __wBlockLegacyGM.setValue(key, value);
        return Promise.resolve();
    };
    GM.deleteValue = function(key) {
        __wBlockLegacyGM.deleteValue(key);
        return Promise.resolve();
    };
    GM.listValues = function() {
        return Promise.resolve(__wBlockLegacyGM.listValues());
    };
    GM.getResourceURL = function(resourceName) {
        return Promise.resolve(__wBlockLegacyGM.getResourceURL(resourceName));
    };
    GM.getResourceUrl = function(resourceName) {
        return Promise.resolve(__wBlockLegacyGM.getResourceUrl(resourceName));
    };
    GM.getResourceText = function(resourceName) {
        return Promise.resolve(__wBlockLegacyGM.getResourceText(resourceName));
    };
    GM.xmlhttpRequest = __wBlockGMRequestPromise;
    GM.xmlHttpRequest = __wBlockGMRequestPromise;

    const GM_info = GM.info;
    const GM_getValue = __wBlockLegacyGM.getValue;
    const GM_setValue = __wBlockLegacyGM.setValue;
    const GM_deleteValue = __wBlockLegacyGM.deleteValue;
    const GM_listValues = __wBlockLegacyGM.listValues;
    const GM_getResourceURL = __wBlockLegacyGM.getResourceURL;
    const GM_getResourceUrl = __wBlockLegacyGM.getResourceUrl;
    const GM_getResourceText = __wBlockLegacyGM.getResourceText;
    const GM_addElement = GM.addElement;
    const GM_addValueChangeListener = GM.addValueChangeListener;
    const GM_removeValueChangeListener = GM.removeValueChangeListener;
    const GM_addStyle = GM.addStyle;
    const GM_setClipboard = GM.setClipboard;
    const GM_openInTab = GM.openInTab;
    const GM_notification = GM.notification;
    const GM_download = GM.download;
    const GM_xmlhttpRequest = __wBlockLegacyGM.xmlhttpRequest;
    const GM_xmlHttpRequest = __wBlockLegacyGM.xmlhttpRequest;
    const GM_registerMenuCommand = GM.registerMenuCommand;
    const GM_unregisterMenuCommand = GM.unregisterMenuCommand;

    ${exposeGMGlobals ? `
    ${exposeGMGlobalsPrefix}
    // Expose GM globals where the page can read them. Content-context scripts keep
    // these in the isolated world; AdGuard Popup Blocker's options page polls for
    // page-visible GM_* functions to decide whether the userscript is installed.
    window.GM_info = GM_info;
    window.GM = GM;

    // Legacy GM function aliases
    window.GM_getValue = GM_getValue;
    window.GM_setValue = GM_setValue;
    window.GM_deleteValue = GM_deleteValue;
    window.GM_listValues = GM_listValues;
    window.GM_getResourceURL = GM_getResourceURL;
    window.GM_getResourceUrl = GM_getResourceUrl;
    window.GM_getResourceText = GM_getResourceText;
    window.GM_addElement = GM_addElement;
    window.GM_addValueChangeListener = GM_addValueChangeListener;
    window.GM_removeValueChangeListener = GM_removeValueChangeListener;
    window.GM_addStyle = GM_addStyle;
    window.GM_setClipboard = GM_setClipboard;
    window.GM_openInTab = GM_openInTab;
    window.GM_notification = GM_notification;
    window.GM_download = GM_download;
    window.GM_xmlhttpRequest = GM_xmlhttpRequest;
    window.GM_xmlHttpRequest = GM_xmlHttpRequest;
    window.GM_registerMenuCommand = GM_registerMenuCommand;
    window.GM_unregisterMenuCommand = GM_unregisterMenuCommand;
    ${exposeGMGlobalsSuffix}
    ` : ``}

    var __wBlockRunUserScript = function() {
        ${script.content}
    };

    try {
        __wBlockRunUserScript();
        wBlockLog('[wBlock UserScript] Finished executing: ${escapeForJS(script.name)}');
    } catch (error) {
        wBlockError('[wBlock UserScript Execution Error] in ${escapeForJS(script.name)}:', error);
        wBlockError('[wBlock UserScript Error Stack]:', error.stack);

        // Show a console warning for userscript errors
        wBlockWarn('[wBlock] Error in userscript "${escapeForJS(script.name)}": ' + (error && error.message ? error.message : String(error)));
    }
})();
        `;
        }
    }

    // Start native lookup immediately even when Safari runs us before the parser
    // has created <html>. waitForDocumentRoot() gates only the final DOM insertion.
    new UserScriptEngine();
}

// Ensure that if this script is injected multiple times (e.g. in iframes),
// each frame gets its own engine, but a single frame doesn't run it multiple times.
// The window.wBlockUserscriptInjectorHasRun flag handles the single-frame case.
})();
